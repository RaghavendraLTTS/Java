package com.ltts.getData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.getData.dto.ProcessData;
import com.ltts.getData.entity.ProcessTable;
import com.ltts.getData.repo.ExecutionDataRepository;
import com.ltts.getData.repo.ProcessDataRepository;
import com.ltts.getData.repo.UserRepository;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ProcessDataController {

//    @Autowired
//    private ProjectDataService processDataService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProcessDataRepository pdr;

    @Autowired
    private ExecutionDataRepository execRepo;
    

    @GetMapping("/ListofToolsData")
    public ResponseEntity<List<ProcessData>> getProcessData() {
        List<ProcessTable> gpd = pdr.getProcessData();
        if(gpd.size() != 0){
            List<ProcessData> responses = gpd.stream()
                    .map(processData -> {
                    	ProcessData response = new ProcessData();
//                    	response.setUsername(processData.getUsername());
                    	response.setClient(processData.getClient());
                    	response.setProject(processData.getProject());
//                    	if (processData.getToolname().equals("Output")) {
//                    	    response.setToolname("PCI-RSI Anomaly");
//                    	} else if (processData.getToolname().equals("PCI")) {
//                    	    response.setToolname("PCI Anomaly");
//                    	} else if (processData.getToolname().equals("RSI")) {
//                    	    response.setToolname("RSI Anomaly");
//                    	}
                    	response.setToolname(processData.getToolname());
                    	response.setProcessInstanceid(processData.getProcessInstanceid());
                    	response.setOutput(processData.getOutput());
                    	response.setTimestamp(processData.getTimestamp());
                    	return response;
                    })
                    .collect(Collectors.toList());
            return ResponseEntity.ok(responses);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    
    @GetMapping("/ListOfWorkflows")
    public ResponseEntity<Map<String, Long>> getProcessDataCount() {
        Long count = execRepo.count();
        Map<String, Long> response = new HashMap<>();
        response.put("ListOfWorkFlows", count);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/ListOfUsers")
    public ResponseEntity<Map<String, Long>> getUsersCount() {
        Long count = userRepository.count();
        Map<String, Long> response = new HashMap<>();
        response.put("ListOfUsers", count);
        return ResponseEntity.ok(response);
    }
    
    
    
    
}