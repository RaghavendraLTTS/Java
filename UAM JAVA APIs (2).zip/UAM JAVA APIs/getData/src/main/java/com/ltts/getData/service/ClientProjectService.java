package com.ltts.getData.service;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.getData.repo.ClientProjectRepository;

@Service
public class ClientProjectService {

    @Autowired
    private ClientProjectRepository clientProjectRepository;

    public List<Map<String, Object>> getClientProjectData() {
        return clientProjectRepository.fetchClientProjectData();
    }
}

