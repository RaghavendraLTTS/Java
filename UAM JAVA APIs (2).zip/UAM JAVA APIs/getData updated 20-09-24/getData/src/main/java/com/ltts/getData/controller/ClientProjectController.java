package com.ltts.getData.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.getData.dto.ClientProjectResponse;
import com.ltts.getData.dto.UsernameRequest;
import com.ltts.getData.service.ClientProjectService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ClientProjectController {

    @Autowired
    private ClientProjectService clientProjectService;

    @GetMapping("/getData")
    public ResponseEntity<List<Map<String, Object>>> getClientProjectData() {
        List<Map<String, Object>> clientProjectData = clientProjectService.getClientProjectData();
        return ResponseEntity.ok(clientProjectData);
    }
    
    @PostMapping("/clients-and-projects")
    public ResponseEntity<List<ClientProjectResponse>> getClientsAndProjects(@RequestBody UsernameRequest request) {
    	System.out.println("Request body : "+ request.getUsername());
        List<ClientProjectResponse> response = clientProjectService.getClientsAndProjectsByUsername(request.getUsername());
        return ResponseEntity.ok(response);
    }
}

