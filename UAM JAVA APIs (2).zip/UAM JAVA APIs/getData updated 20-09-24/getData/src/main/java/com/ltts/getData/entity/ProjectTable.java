package com.ltts.getData.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Project_Table")
public class ProjectTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long projectId;
    
    @Column(name = "project_name")
    private String projectName;

    @Column(name = "client_id")
    private Long clientClientId;

    public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Long getClientClientId() {
		return clientClientId;
	}

	public void setClientClientId(Long clientClientId) {
		this.clientClientId = clientClientId;
	}

	
}