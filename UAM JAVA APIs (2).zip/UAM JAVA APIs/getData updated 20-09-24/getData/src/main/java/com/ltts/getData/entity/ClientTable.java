package com.ltts.getData.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Client_Table")
public class ClientTable {

    public Integer getClientId() {
		return clientId;
	}

	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer clientId;

    @Column(nullable = false, unique = true)
    private String clientName;
}

