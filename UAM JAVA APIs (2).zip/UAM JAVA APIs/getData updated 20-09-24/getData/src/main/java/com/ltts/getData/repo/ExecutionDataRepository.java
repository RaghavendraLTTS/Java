package com.ltts.getData.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.getData.entity.ExecutionData;

public interface ExecutionDataRepository extends JpaRepository<ExecutionData, Long>{

}
