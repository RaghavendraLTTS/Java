package com.ltts.getData.dto;

import java.util.List;

public class ClientProjectResponse {
    
    private String client;
    
    private List<String> projects;
    
    public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public List<String> getProjects() {
		return projects;
	}

	public void setProjects(List<String> projects) {
		this.projects = projects;
	}

	
    
    
}