//package com.ltts.getData.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.ltts.getData.dto.ProcessData;
//import com.ltts.getData.repo.ProcessDataRepository;
//
//@Service
//public class ProjectDataService {
//	
//	@Autowired
//    private ProcessDataRepository processDataRepository;
//
//	public List<ProcessData> getProcessData() {
//        return processDataRepository.getProcessData();
//    }
//}
