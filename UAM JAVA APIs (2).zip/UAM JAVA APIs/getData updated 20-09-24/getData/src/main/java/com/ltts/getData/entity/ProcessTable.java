package com.ltts.getData.entity;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "process_data1")
public class ProcessTable {
	
	@Id
	private Long id;
//	private Long transactionid;
	private String username;
    private String client;
    private String project;
    private String toolname;
    private String processInstanceid;
    private String timestamp;
    private String output;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
//	public Long getTransactionid() {
//		return transactionid;
//	}
//	public void setTransactionid(Long transactionid) {
//		this.transactionid = transactionid;
//	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getToolname() {
		return toolname;
	}
	public void setToolname(String toolname) {
		this.toolname = toolname;
	}
	public String getProcessInstanceid() {
		return processInstanceid;
	}
	public void setProcessInstanceid(String processInstanceid) {
		this.processInstanceid = processInstanceid;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	
   
	
	

}
