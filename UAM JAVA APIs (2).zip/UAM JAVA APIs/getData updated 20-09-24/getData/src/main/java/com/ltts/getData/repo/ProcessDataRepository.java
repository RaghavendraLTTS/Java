package com.ltts.getData.repo;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ltts.getData.dto.ProcessData;
import com.ltts.getData.entity.ProcessTable;


public interface ProcessDataRepository extends JpaRepository<ProcessTable, Long> {

    @Query(value = "SELECT id, username, client, project, toolname, process_instanceId, timestamp, 'View' AS output FROM process_data1", nativeQuery = true)
    
//    @ConstructorResult(targetClass = ProcessData.class, columns = {
//            @ColumnResult(name = "username", type = String.class),
//            @ColumnResult(name = "client", type = String.class),
//            @ColumnResult(name = "project", type = String.class),
//            @ColumnResult(name = "toolname", type = String.class),
//            @ColumnResult(name = "process_instanceId", type = Long.class),
//            @ColumnResult(name = "timestamp", type = Timestamp.class),
//            @ColumnResult(name = "output", type = String.class)
//    })
    List<ProcessTable> getProcessData();
}
