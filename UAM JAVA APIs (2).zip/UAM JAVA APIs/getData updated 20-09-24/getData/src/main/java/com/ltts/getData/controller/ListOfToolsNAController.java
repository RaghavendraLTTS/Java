package com.ltts.getData.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

import com.ltts.getData.dto.ClientProjectCombination;
import com.ltts.getData.dto.ClientProjectResponse;
import com.ltts.getData.dto.ProcessData;
import com.ltts.getData.dto.UsernameRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ListOfToolsNAController {

	private static final Logger log = LoggerFactory.getLogger(ListOfToolsNAController.class);
	private RestTemplate restTemplate = new RestTemplate();
	
	@Value("${my.cpapi}")
    private String cpapi;
    
    @Value("${my.ltdNAapi}")
    private String ltdNAapi;
    
    @PostMapping("/ListofToolsDataNA")
    public ResponseEntity<List<ProcessData>> getProcessDataWithUsername(@RequestBody UsernameRequest request) {
        try {
            // Call the first API to get the client project combinations
            ResponseEntity<List<ClientProjectResponse>> response = getClientsAndProjects(request);
            System.out.println(" api response : " + response.getBody());

            if (response.getStatusCode() == HttpStatus.OK) {
                List<ClientProjectResponse> clientProjectResponses = response.getBody();
                List<ClientProjectCombination> combinations = new ArrayList<>();

                for (ClientProjectResponse clientProjectResponse : clientProjectResponses) {
                    ClientProjectCombination combination = new ClientProjectCombination();
                    combination.setClient(clientProjectResponse.getClient());
                    combination.setProjects(clientProjectResponse.getProjects());
                    combinations.add(combination);
                }

                // Call the second API with the client project combinations
                return getProcessData(combinations);
            } else {
                return ResponseEntity.status(response.getStatusCode()).build();
            }
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling API: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to API: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error processing request: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

   
    private ResponseEntity<List<ClientProjectResponse>> getClientsAndProjects(UsernameRequest request) {
        try {
            String baseUrl = cpapi; 
            restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(baseUrl));
            return restTemplate.exchange("/clients-and-projects", HttpMethod.POST, new HttpEntity<>(request), new ParameterizedTypeReference<List<ClientProjectResponse>>() {});
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling first API: {}", e.getMessage());
            throw e;
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to first API: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error calling first API: {}", e.getMessage());
            throw e;
        }
    }

    
    private ResponseEntity<List<ProcessData>> getProcessData(List<ClientProjectCombination> combinations) {
        try {
            String baseUrl = ltdNAapi; 
            restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(baseUrl));
            return restTemplate.exchange("/combinations", HttpMethod.POST, new HttpEntity<>(combinations), new ParameterizedTypeReference<List<ProcessData>>() {});
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling second API: {}", e.getMessage());
            throw e;
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to second API: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error calling second API: {}", e.getMessage());
            throw e;
        }
    }
}
