package com.ltts.getData.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.getData.dto.ClientProjectCombination;
import com.ltts.getData.dto.ProcessData;
import com.ltts.getData.entity.ProcessTable;
import com.ltts.getData.repo.ExecutionDataRepository;
import com.ltts.getData.repo.ProcessDataRepository;
import com.ltts.getData.repo.UserRepository;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ProcessDataController {

	@Value("${spring.datasource.url}")
    private String jdbcurl;
    
    @Value("${spring.datasource.username}")
    private String username;
    
    @Value("${spring.datasource.password}")
    private String password;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProcessDataRepository pdr;

    @Autowired
    private ExecutionDataRepository execRepo;
    

    @GetMapping("/ListofToolsData")
    public ResponseEntity<List<ProcessData>> getProcessData() {
        List<ProcessTable> gpd = pdr.getProcessData();
        if(gpd.size() != 0){
            List<ProcessData> responses = gpd.stream()
                    .map(processData -> {
                    	ProcessData response = new ProcessData();
//                    	response.setUsername(processData.getUsername());
                    	response.setClient(processData.getClient());
                    	response.setProject(processData.getProject());
                    	response.setToolname(processData.getToolname());
                    	response.setProcessInstanceid(processData.getProcessInstanceid());
                    	response.setOutput(processData.getOutput());
                    	response.setTimestamp(processData.getTimestamp());
                    	return response;
                    })
                    .collect(Collectors.toList());
            return ResponseEntity.ok(responses);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    @PostMapping("/combinations")
    public ResponseEntity<List<ProcessData>> getProcessData(@RequestBody List<ClientProjectCombination> combinations) {
      StringBuilder query = new StringBuilder("SELECT id, username, client, project, toolname, process_instanceId, timestamp, 'View' AS output FROM process_data1 WHERE ");
      
      for (int i = 0; i < combinations.size(); i++) {
        ClientProjectCombination combination = combinations.get(i);
        query.append("(")
              .append("client = '").append(combination.getClient()).append("' AND project IN (");
        
        for (String project : combination.getProjects()) {
          query.append("'").append(project).append("',");
        }
        
        query.deleteCharAt(query.length() - 1); // remove trailing comma
        query.append("))");
        
        if (i < combinations.size() - 1) {
          query.append(" OR ");
        }
      }
      
      System.out.println("query print : "+ query.toString());
      try (Connection conn = DriverManager.getConnection(jdbcurl, username, password);		
               PreparedStatement stmt = conn.prepareStatement(query.toString())) {
        
        ResultSet resultSet = stmt.executeQuery();
        
        List<ProcessTable> gpd = new ArrayList<>();
        while (resultSet.next()) {
          ProcessTable processTable = new ProcessTable();
//          processTable.setId(resultSet.getInt("id"));
          processTable.setUsername(resultSet.getString("username"));
          processTable.setClient(resultSet.getString("client"));
          processTable.setProject(resultSet.getString("project"));
          processTable.setToolname(resultSet.getString("toolname"));
          processTable.setProcessInstanceid(resultSet.getString("process_instanceId"));
          processTable.setTimestamp(resultSet.getString("timestamp"));
          processTable.setOutput(resultSet.getString("output"));
          
          gpd.add(processTable);
        }
        
        if(gpd.size() != 0){
          List<ProcessData> responses = gpd.stream()
                  .map(processData -> {
                   ProcessData response = new ProcessData();
                   response.setClient(processData.getClient());
                   response.setProject(processData.getProject());
                   response.setToolname(processData.getToolname());
                   response.setProcessInstanceid(processData.getProcessInstanceid());
                   response.setOutput(processData.getOutput());
                   response.setTimestamp(processData.getTimestamp());
                   return response;
                  })
                  .collect(Collectors.toList());
          
          return ResponseEntity.ok(responses);
        } else {
          return ResponseEntity.noContent().build();
        }
      } catch (SQLException e) {
        // handle SQLException
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
      }
    }
    
    @GetMapping("/ListOfWorkflows")
    public ResponseEntity<Map<String, Long>> getProcessDataCount() {
        Long count = execRepo.count();
        Map<String, Long> response = new HashMap<>();
        response.put("ListOfWorkFlows", count);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/ListOfUsers")
    public ResponseEntity<Map<String, Long>> getUsersCount() {
        Long count = userRepository.count();
        Map<String, Long> response = new HashMap<>();
        response.put("ListOfUsers", count);
        return ResponseEntity.ok(response);
    }
    
    
    
    
}