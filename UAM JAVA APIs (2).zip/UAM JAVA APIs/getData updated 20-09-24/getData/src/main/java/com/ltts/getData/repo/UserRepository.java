package com.ltts.getData.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.getData.entity.UserTable;

public interface UserRepository extends JpaRepository<UserTable, Long>{

}
