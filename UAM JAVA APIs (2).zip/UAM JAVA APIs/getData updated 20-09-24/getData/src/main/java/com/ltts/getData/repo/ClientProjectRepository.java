package com.ltts.getData.repo;


import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ltts.getData.entity.ClientTable;

public interface ClientProjectRepository extends JpaRepository<ClientTable, Long> {

    @Query(value = "SELECT a.client_id, a.client_name, b.project_id, b.project_name, b.client_id as projectClientId " +
                   "FROM Client_Table a, Project_Table b " +
                   "WHERE a.client_id = b.client_id ORDER BY a.client_id ASC", nativeQuery = true)
    List<Map<String, Object>> fetchClientProjectData();
}






