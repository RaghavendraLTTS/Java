package com.ltts.getData.dto;

import java.time.LocalDateTime;

public class ProcessData {
	
//    private String username;
    private String client;
    private String project;
    private String toolname;
    private String processInstanceId;
    private String timestamp;
    private String output;
    
//    public String getUsername() {
//		return username;
//	}
//	public void setUsername(String username) {
//		this.username = username;
//	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getToolname() {
		return toolname;
	}
	public void setToolname(String toolname) {
		this.toolname = toolname;
	}
	public String getProcessInstanceId() {
		return processInstanceId;
	}
	public void setProcessInstanceid(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	
    
   
	

}
