package com.ltts.tooldata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TooldataApplicationTests {

	@Test
	void contextLoads() {
	}

}
