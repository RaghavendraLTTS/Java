package com.ltts.tooldata.model;

public interface ClientProjectToolProjection {
    Long getToolId();
    Long getClientId();
    Long getProjectId();
    String getClientName();
    String getProjectName();
    String getToolName();
}

