package com.ltts.tooldata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TooldataApplication {

	public static void main(String[] args) {
		SpringApplication.run(TooldataApplication.class, args);
	}

}
