package com.ltts.tooldata.model;

public interface UserProjectProjection {
    Long getClientId();
    String getClientName();
    Long getProjectId();
    String getProjectName();
    String getToolsSelected();
}

