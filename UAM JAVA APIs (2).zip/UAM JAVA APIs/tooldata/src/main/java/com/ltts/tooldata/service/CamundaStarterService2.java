package com.ltts.tooldata.service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.ltts.tooldata.model.ExecutionDataRequest;
import com.ltts.tooldata.model.ToolConfigToComundaReq;

import jakarta.annotation.PostConstruct;

@Service
public class CamundaStarterService2 {

	private final HttpClient httpClient = HttpClient.newHttpClient();
	private final ObjectMapper objectMapper = new ObjectMapper();

	@Value("${my.executiondataURL}")
	private String URL;

	@Value("${my.toolConfigToComundaURL}")
	private String URL1;

	@Value("${my.camundaStartProcessUrl}")
	private String URL2;

//	@Autowired
	private ExecutorService executorService;

	@PostConstruct
	public void init() {
		executorService = Executors.newFixedThreadPool(1);

	}

	public String startProcess(ToolConfigToComundaReq jsonInput) throws Exception {
//        // Call the first API
//        String convertFilesUrl = "http://localhost:8080/api/convertFilesToJson";
//        HttpRequest convertFilesRequest = HttpRequest.newBuilder()
//                .uri(new URI(convertFilesUrl))
//                .header("Content-Type", "application/json")
//                .POST(HttpRequest.BodyPublishers.noBody())
//                .build();
//
//        HttpResponse<String> convertFilesResponse = httpClient.send(convertFilesRequest, HttpResponse.BodyHandlers.ofString());
//
//        // Handle the response from /convertFilesToJson
//        ArrayNode rawData = null;
//        if (convertFilesResponse.statusCode() == 200) {
//            rawData = (ArrayNode) objectMapper.readTree(convertFilesResponse.body());
//            System.out.println("Files converted successfully: " + rawData);
//        } else {
//            System.out.println("Error converting files: " + convertFilesResponse.statusCode());
//        }

		String execApiUrl = URL;
		ExecutionDataRequest exeReq = new ExecutionDataRequest();
		exeReq.setUsername(jsonInput.getUsername());
		exeReq.setClientName(jsonInput.getClientName());
		exeReq.setProjectName(jsonInput.getProjectName());
		exeReq.setTools(jsonInput.getTools().toArray(new String[jsonInput.getTools().size()]));
//		System.out.println("execRequest : " + exeReq);

		String jsonInputString1 = objectMapper.writeValueAsString(exeReq);
//		System.out.println("JSON Input String: " + jsonInputString1);

		HttpRequest toolConfigRequest1 = HttpRequest.newBuilder().uri(new URI(execApiUrl))
				.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(jsonInputString1))
				.build();

		HttpClient client = HttpClient.newHttpClient();

		try {
			HttpResponse<String> response = client.send(toolConfigRequest1, HttpResponse.BodyHandlers.ofString());
			System.out.println("Response: " + response.body());
		} catch (IOException | InterruptedException e) {
			System.err.println("Error sending request: " + e.getMessage());
		}

		// Call the second API
		String toolConfigUrl = URL1;
		String jsonInputString = objectMapper.writeValueAsString(jsonInput);
		HttpRequest toolConfigRequest = HttpRequest.newBuilder().uri(new URI(toolConfigUrl))
				.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(jsonInputString))
				.build();

		HttpResponse<String> toolConfigResponse = httpClient.send(toolConfigRequest,
				HttpResponse.BodyHandlers.ofString());

		// Handle the response from /toolConfigToComunda
		ArrayNode toolsData = null;
		if (toolConfigResponse.statusCode() == 200) {
			toolsData = (ArrayNode) objectMapper.readTree(toolConfigResponse.body());
			System.out.println("Tools printed successfully: " + toolsData);
		} else {
			System.out.println("Error printing tools: " + toolConfigResponse.statusCode());
		}

		// Prepare variables to be passed to the Camunda process instance
		Map<String, Object> variables = new HashMap<>();
//        variables.put("rawData", createCamundaVariable(objectMapper.writeValueAsString(rawData), "Json"));
		String uuid = UUID.randomUUID().toString();
		variables.put("uniqueProcessId", createCamundaVariable(uuid, "String"));
		variables.put("toolsData", createCamundaVariable(objectMapper.writeValueAsString(toolsData), "Json"));

		// Create the final JSON payload
		Map<String, Object> camundaPayload = new HashMap<>();
		camundaPayload.put("variables", variables);
		camundaPayload.put("businessKey", "myBusinessKey"); // Add any additional keys you need
		String camundaVariablesJson = objectMapper.writeValueAsString(camundaPayload);
		System.out.println("CAMUNDA VARIABLES: " + camundaVariablesJson);

		executorService.execute(() -> {

			String camundaStartProcessUrl = URL2;
			HttpRequest camundaRequest;
			try {

				camundaRequest = HttpRequest.newBuilder().uri(new URI(camundaStartProcessUrl))
						.header("Content-Type", "application/json")
						.POST(HttpRequest.BodyPublishers.ofString(camundaVariablesJson)).build();

//				httpClient.send(camundaRequest, HttpResponse.BodyHandlers.ofString());
				System.out.println("Camunda Response : "
						+ httpClient.send(camundaRequest, HttpResponse.BodyHandlers.ofString()).body());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		});
		return uuid;
	}

	private Map<String, Object> createCamundaVariable(String value, String type) {
		Map<String, Object> variable = new HashMap<>();
		variable.put("value", value);
		variable.put("type", type);
		return variable;
	}
}