package com.ltts.tooldata.service;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ltts.tooldata.entity.ClientTable;
import com.ltts.tooldata.model.CompositeDeleteRequest;
import com.ltts.tooldata.model.CompositeRequest;
import com.ltts.tooldata.entity.ProjectTable;
import com.ltts.tooldata.entity.Tools;
import com.ltts.tooldata.repo.ClientsRepository;
import com.ltts.tooldata.repo.ProjectRepository;
import com.ltts.tooldata.repo.ToolsRepository;

@Service
public class CPTUpdateDeleteService {

    @Autowired
    private ClientsRepository clientsRepository;

    @Autowired
    private ProjectRepository projectsRepository;

    @Autowired
    private ToolsRepository toolsRepository;

//    @Transactional
//    public void saveCompositeEntity(CompositeRequest request) {
//        // Check if the client exists
//        ClientTable client = clientsRepository.findByClientName(request.getClientName());
//
//        if (client == null) {
//            // Create a new client if it doesn't exist
//            client = new ClientTable();
//            client.setClientName(request.getClientName());
//            client = clientsRepository.save(client); // Save the new client
//        }
//
//        // Check if the project exists under the same client
//        final ProjectTable finalProject;  // Declare final variable for project
//
//        ProjectTable existingProject = projectsRepository.findByProjectNameAndClient(request.getProjectName(), client);
//
//        if (existingProject != null) {
//            finalProject = existingProject;  // Use the existing project
//        } else {
//            // Create a new project if it doesn't exist
//            ProjectTable newProject = new ProjectTable();
//            newProject.setProjectName(request.getProjectName());
//            newProject.setClient(client);
//            finalProject = projectsRepository.save(newProject); // Save the new project
//        }
//
//        // Now, check for tools and add them if they are not already mapped to the project
//        List<Tools> existingTools = toolsRepository.findByProject(finalProject);
//
//        List<String> existingToolNames = existingTools.stream()
//                .map(Tools::getToolName)
//                .collect(Collectors.toList());
//
//        // Add only the tools that are not already mapped to the project
//        List<Tools> newTools = request.getTools().stream()
//                .filter(toolRequest -> !existingToolNames.contains(toolRequest.getToolName())) // Only add new tools
//                .map(toolRequest -> {
//                    Tools tool = new Tools();
//                    tool.setToolName(toolRequest.getToolName());
//                    tool.setProject(finalProject); // Use finalProject here
//                    return tool;
//                }).collect(Collectors.toList());
//
//        if (!newTools.isEmpty()) {
//            toolsRepository.saveAll(newTools); // Save new tools
//        }
//    }
    
    @Transactional
    public String saveCompositeEntity(CompositeRequest request) {
        StringBuilder message = new StringBuilder();

        // Check if the client exists
        ClientTable client = clientsRepository.findByClientName(request.getClientName());

        if (client == null) {
            // Create a new client if it doesn't exist
            client = new ClientTable();
            client.setClientName(request.getClientName());
            client = clientsRepository.save(client);
            message.append("Client created. ");
        } else {
            message.append("Client already exists. ");
        }

        // Check if the project exists under the same client
        ProjectTable existingProject = projectsRepository.findByProjectNameAndClient(request.getProjectName(), client);

        final ProjectTable finalProject;

        if (existingProject != null) {
            finalProject = existingProject;
            message.append("Project already exists. ");
        } else {
            // Create a new project if it doesn't exist
            ProjectTable newProject = new ProjectTable();
            newProject.setProjectName(request.getProjectName());
            newProject.setClient(client);
            finalProject = projectsRepository.save(newProject);
            message.append("Project created. ");
        }

        // Now, check for tools and add them if they are not already mapped to the project
        List<Tools> existingTools = toolsRepository.findByProject(finalProject);

        List<String> existingToolNames = existingTools.stream()
                .map(Tools::getToolName)
                .collect(Collectors.toList());

        List<Tools> newTools = request.getTools().stream()
                .filter(toolRequest -> !existingToolNames.contains(toolRequest.getToolName())) // Only add new tools
                .map(toolRequest -> {
                    Tools tool = new Tools();
                    tool.setToolName(toolRequest.getToolName());
                    tool.setProject(finalProject);
                    return tool;
                }).collect(Collectors.toList());

        if (!newTools.isEmpty()) {
            toolsRepository.saveAll(newTools);
            message.append("New tools added. ");
        } else {
            message.append("All tools already exist. ");
        }

        return message.toString();
    }
    
    @Transactional
    public void deleteCompositeEntity(CompositeDeleteRequest request) {
        if (request.getToolIds() != null && !request.getToolIds().isEmpty()) {
            toolsRepository.deleteAllById(request.getToolIds());
        }

        if (request.getProjectId() != null) {
            projectsRepository.deleteById(request.getProjectId());
        }

        if (request.getClientId() != null) {
            clientsRepository.deleteById(request.getClientId());
        }
    }
}