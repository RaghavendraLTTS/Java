package com.ltts.tooldata.model;

public class PredefinedToolReq {

	 private String toolname;

	    // Getter and setter
	    public String getToolname() {
	        return toolname;
	    }

	    public void setToolnames(String toolname) {
	        this.toolname = toolname;
	    }
}