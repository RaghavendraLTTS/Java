package com.ltts.tooldata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.tooldata.entity.ToolsAll;

public interface ToolsAllRepo extends JpaRepository<ToolsAll, Integer> {
}
