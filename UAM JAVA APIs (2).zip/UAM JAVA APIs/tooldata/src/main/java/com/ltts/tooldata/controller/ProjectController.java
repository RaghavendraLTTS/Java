package com.ltts.tooldata.controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.ltts.tooldata.entity.ToolsAll;
import com.ltts.tooldata.model.ClientProjectToolProjection;
import com.ltts.tooldata.model.CompositeDeleteRequest;
import com.ltts.tooldata.model.CompositeRequest;
import com.ltts.tooldata.model.PredefinedToolReq;
import com.ltts.tooldata.model.PredefinedToolsRes;
import com.ltts.tooldata.model.ToolConfig;
import com.ltts.tooldata.model.ToolConfigToComundaReq;
import com.ltts.tooldata.model.UserProjectProjection;
import com.ltts.tooldata.service.CPTUpdateDeleteService;
import com.ltts.tooldata.service.ProjectService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/projects")
public class ProjectController {

    @Autowired
    private ProjectService projectService;
    
    @Autowired
    private CPTUpdateDeleteService compositeService;
    
    @Value("${spring.datasource.url}")
    private String jdbcurl;
    
    @Value("${spring.datasource.username}")
    private String username;
    
    @Value("${spring.datasource.password}")
    private String password;

    @GetMapping("/getDataSA")
    public ResponseEntity<List<ClientProjectToolProjection>> getClientProjectToolData() {
        try {
            List<ClientProjectToolProjection> data = projectService.getClientProjectToolData();
            return ResponseEntity.ok(data);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PostMapping("/getDataNA")
    public ResponseEntity<List<UserProjectProjection>> getUserProjects(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        if (username == null || username.isEmpty()) {
            return ResponseEntity.badRequest().body(null);
        }

        try {
            List<UserProjectProjection> data = projectService.getUserProjectsByUsername(username);
            return ResponseEntity.ok(data);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    @GetMapping("/getToolConfig")
    public List<ToolConfig> getAllToolConfigs() {
        return projectService.getAllToolConfigs();
    }
    
    @GetMapping("/getToolsAll")
    public List<ToolsAll> getToolsAll(){
    	return projectService.getToolsAll();
    }
    
    @PostMapping("/toolConfigToComunda")
	public ResponseEntity<ArrayNode> echoJson(@RequestBody ToolConfigToComundaReq jsonInput){
    	try {
    		ObjectMapper objectMapper = new ObjectMapper();
    		
    		String jsonString = objectMapper.writeValueAsString(jsonInput);
    		JsonNode jsonNode = objectMapper.readTree(jsonString);
    		
    		ArrayNode arrayNode = objectMapper.createArrayNode();
    		arrayNode.add(jsonNode);
    		
    		return ResponseEntity.ok(arrayNode);
			
		} catch (Exception e) {
			// TODO: handle exception
			return ResponseEntity.status(500).build();
		}
		
	}
    
    @PostMapping("/saveToolConfig")
    public ResponseEntity<String> saveOrUpdate(@RequestBody ToolConfig toolConfig){
    	boolean exists = projectService.existsById(toolConfig.getToolname());
    	projectService.saveOrUpdate(toolConfig);
    	if(exists) {
    		return ResponseEntity.ok("Tool updated successfully");
    	} else {
    		return ResponseEntity.ok("Tool added successfully");
    	}
    }
    
    
    @PostMapping("/predefinedtools")
    public List<PredefinedToolsRes> getPredefinedTools(@RequestBody PredefinedToolReq request) {
       String toolName = request.getToolname();
       PredefinedToolsRes res = new PredefinedToolsRes(toolName, projectService.getPredefinedToolsByToolname(toolName));
       return Collections.singletonList(res);
       
    }
    
//    @PostMapping("/updatecpt")
//    public ResponseEntity<String> createCompositeEntity(@RequestBody CompositeRequest request) {
//        compositeService.saveCompositeEntity(request);
//        return ResponseEntity.ok("Saved");
//        
//    }
    
    @PostMapping("/updatecpt")
    public ResponseEntity<String> createCompositeEntity(@RequestBody CompositeRequest request) {
        String responseMessage = compositeService.saveCompositeEntity(request);
        return ResponseEntity.ok(responseMessage);
    }
    
    
    @DeleteMapping("/deletecpt")
    public ResponseEntity<String> deleteCompositeEntity(@RequestBody CompositeDeleteRequest request) {
        compositeService.deleteCompositeEntity(request);
        return ResponseEntity.ok("Deleted");
    }
    
}

