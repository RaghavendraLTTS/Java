package com.ltts.tooldata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.tooldata.model.ToolConfig;


public interface ToolRepo extends JpaRepository<ToolConfig, String> {
}
