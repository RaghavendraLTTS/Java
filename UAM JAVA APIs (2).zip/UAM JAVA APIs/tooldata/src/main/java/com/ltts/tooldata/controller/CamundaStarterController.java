package com.ltts.tooldata.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.tooldata.model.ToolConfigToComundaReq;
import com.ltts.tooldata.service.CamundaStarterService2;


@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class CamundaStarterController {

    @Autowired
    private CamundaStarterService2 processStarter;

    
    @PostMapping("/startProcess")
    public String startProcess(@RequestBody ToolConfigToComundaReq jsonInput) {
        try {
        	return processStarter.startProcess(jsonInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "process start Error :"+ e.getMessage();
		}
        
    }
}