package com.ltts.tooldata.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "toolconfig")
public class PredefinedTools {

    @Id
    private String toolname;
    private String predefinedtools;

    // Getters and setters
    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getPredefinedtools() {
        return predefinedtools;
    }

    public void setPredefinedtools(String predefinedtools) {
        this.predefinedtools = predefinedtools;
    }
}

