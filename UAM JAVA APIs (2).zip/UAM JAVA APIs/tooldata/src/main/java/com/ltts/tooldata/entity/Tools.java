package com.ltts.tooldata.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tools")
public class Tools {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tool_id")
    private Long toolId;
    
    @Column(name = "tool_name", nullable = false)
    private String toolName;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectTable project;

    public Long getToolId() {
		return toolId;
	}

	public void setToolId(Long toolId) {
		this.toolId = toolId;
	}

	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}

	public ProjectTable getProject() {
		return project;
	}

	public void setProject(ProjectTable project) {
		this.project = project;
	}

	

 
}
