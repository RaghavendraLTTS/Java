package com.ltts.tooldata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.tooldata.entity.ClientTable;


public interface ClientsRepository extends JpaRepository<ClientTable, Integer> {
	ClientTable findByClientName(String clientName);
}