package com.ltts.tooldata.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ltts.tooldata.entity.ClientTable;
import com.ltts.tooldata.entity.ProjectTable;
import com.ltts.tooldata.model.ClientProjectToolProjection;
import com.ltts.tooldata.model.UserProjectProjection;

@Repository
public interface ProjectRepository extends JpaRepository<ProjectTable, Integer> {

    @Query(value = "SELECT t.tool_id AS toolId, c.client_id AS clientId, p.project_id AS projectId, " +
                   "c.client_name AS clientName, p.project_name AS projectName, " +
                   "t.tool_name AS toolName " +
                   "FROM client_table c, tools t, project_table p " +
                   "WHERE c.client_id = p.client_id AND p.project_id = t.project_id", nativeQuery = true)
    List<ClientProjectToolProjection> findClientProjectToolData();

    @Query(value = "SELECT DISTINCT a.client_id AS clientId, a.client_name AS clientName, " +
                   "b.project_id AS projectId, b.project_name AS projectName, c.tools_selected AS toolsSelected " +
                   "FROM client_table a " +
                   "JOIN project_table b ON a.client_id = b.client_id " +
                   "JOIN user_project c ON a.client_id = c.client_id AND b.project_id = c.project_id " +
                   "WHERE c.user_id = (SELECT user_id FROM usertable WHERE username = :username)", nativeQuery = true)
    List<UserProjectProjection> findUserProjectsByUsername(@Param("username") String username);
    
    
    ProjectTable findByProjectNameAndClient(String projectName, ClientTable client);
}

