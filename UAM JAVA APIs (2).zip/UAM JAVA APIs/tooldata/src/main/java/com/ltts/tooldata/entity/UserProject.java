package com.ltts.tooldata.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_project")
public class UserProject {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userProj_id")
    private Long userProjId;
    
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserTable user;

    @ManyToOne
    @JoinColumn(name = "client_id", nullable = false)
    private ClientTable client;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectTable project;

    @Column(name = "tools_selected", nullable = false)
    private String toolsSelected;

    public Long getUserProjId() {
		return userProjId;
	}

	public void setUserProjId(Long userProjId) {
		this.userProjId = userProjId;
	}

	public UserTable getUser() {
		return user;
	}

	public void setUser(UserTable user) {
		this.user = user;
	}

	public ClientTable getClient() {
		return client;
	}

	public void setClient(ClientTable client) {
		this.client = client;
	}

	public ProjectTable getProject() {
		return project;
	}

	public void setProject(ProjectTable project) {
		this.project = project;
	}

	public String getToolsSelected() {
		return toolsSelected;
	}

	public void setToolsSelected(String toolsSelected) {
		this.toolsSelected = toolsSelected;
	}

	

}
