package com.ltts.tooldata.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.tooldata.entity.ProjectTable;
import com.ltts.tooldata.entity.Tools;


public interface ToolsRepository extends JpaRepository<Tools, Integer> {
	List<Tools> findByProject(ProjectTable project);
}