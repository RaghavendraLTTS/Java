package com.ltts.tooldata.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.tooldata.entity.PredefinedTools;
import com.ltts.tooldata.entity.ToolsAll;
import com.ltts.tooldata.model.ClientProjectToolProjection;
import com.ltts.tooldata.model.ToolConfig;
import com.ltts.tooldata.model.UserProjectProjection;
import com.ltts.tooldata.repo.PredefinedToolRepo;
import com.ltts.tooldata.repo.ProjectRepository;
import com.ltts.tooldata.repo.ToolRepo;
import com.ltts.tooldata.repo.ToolsAllRepo;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;
    
    @Autowired
    private ToolRepo toolConfigRepository;
    
    @Autowired
    private ToolsAllRepo tRepo;
    
    @Autowired
    private PredefinedToolRepo predefinedToolRepo;

    public List<ClientProjectToolProjection> getClientProjectToolData() {
        return projectRepository.findClientProjectToolData();
    }

    public List<UserProjectProjection> getUserProjectsByUsername(String username) {
        return projectRepository.findUserProjectsByUsername(username);
    }
    
    public List<ToolConfig> getAllToolConfigs() {
        return toolConfigRepository.findAll();
    }
    
    public List<ToolsAll> getToolsAll() {
        return tRepo.findAll();
    }
    
    public ToolConfig saveOrUpdate(ToolConfig toolConfig) {
    	return toolConfigRepository.save(toolConfig);
    }
    
    public boolean existsById(String toolname) {
    	return toolConfigRepository.existsById(toolname);
    }
    
    public List<String> getPredefinedToolsByToolname(String toolname) {
    	PredefinedTools toolConfig = predefinedToolRepo.findByToolname(toolname);
        if (toolConfig != null && toolConfig.getPredefinedtools() != null) {
        	return Arrays.asList(toolConfig.getPredefinedtools().split(","));
        }
        return null;
    }
}

