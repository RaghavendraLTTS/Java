//package com.ltts.onboardusers.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ltts.onboardusers.dto.ManageUserResponse;
//import com.ltts.onboardusers.service.ManageUserService;
//
//@RestController
//@CrossOrigin(origins = "${ui.crossOrigin}")
//@RequestMapping("/api")
//public class ManageUserController {
//
//    @Autowired
//    private ManageUserService userProjectService;
//
//    @GetMapping("/manageUsers")
//    public List<ManageUserResponse> getUserProjectData() {
//        return userProjectService.getUserProjectData();
//    }
//}
