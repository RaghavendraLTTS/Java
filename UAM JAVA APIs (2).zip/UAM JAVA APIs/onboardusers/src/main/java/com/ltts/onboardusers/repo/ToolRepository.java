package com.ltts.onboardusers.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ltts.onboardusers.entity.ToolEntity;

public interface ToolRepository extends JpaRepository<ToolEntity, Long> {
}
