package com.ltts.onboardusers.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ltts.onboardusers.dto.UserOnboardingDTO;
import com.ltts.onboardusers.entity.ClientEntity;
import com.ltts.onboardusers.entity.ProjectEntity;
import com.ltts.onboardusers.entity.UserEntity;
import com.ltts.onboardusers.entity.UserProjectEntity;
import com.ltts.onboardusers.repo.ClientRepository;
import com.ltts.onboardusers.repo.ProjectRepository;
import com.ltts.onboardusers.repo.UserProjectRepository;
import com.ltts.onboardusers.repo.UserProjectRepositoryNative;
import com.ltts.onboardusers.repo.UserRepository;

import jakarta.transaction.Transactional;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private UserProjectRepository userProjectRepository;

    @Autowired
    private UserProjectRepositoryNative userProjectRepositorynative;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public String onboardUserProject(UserOnboardingDTO userOnboardingDTO) {
        StringBuilder responseMessage = new StringBuilder();

        // Validate username
        if (!userOnboardingDTO.getUsername().endsWith("@nokia.com")) {
            throw new IllegalArgumentException("Username must end with '@nokia.com'");
        }

        // Encode the password
        String encodedPassword = passwordEncoder.encode(userOnboardingDTO.getPassword());

        // Check if the user exists
        UserEntity existingUser = userRepository.findByUsername(userOnboardingDTO.getUsername());
        if (existingUser == null) {
            // User doesn't exist, create user
            userRepository.saveUser(userOnboardingDTO.getUsername(), encodedPassword, userOnboardingDTO.getRole());
            existingUser = userRepository.findByUsername(userOnboardingDTO.getUsername()); // Fetch the newly created user
            responseMessage.append("User added. ");
        }

        // Check if the client exists
        ClientEntity existingClient = clientRepository.findByClientName(userOnboardingDTO.getClientName());
        if (existingClient == null) {
            // Client doesn't exist, create client
            clientRepository.save(new ClientEntity(userOnboardingDTO.getClientName()));
            existingClient = clientRepository.findByClientName(userOnboardingDTO.getClientName()); // Fetch the newly created client
            responseMessage.append("Client added. ");
        }

        // Check the combination of user, client, and project in the user_project table
        UserProjectEntity userProjectEntity = userProjectRepository.findByUser_UserIdAndClient_ClientIdAndProject_ProjectName(
                existingUser.getUserId(),
                existingClient.getClientId(),
                userOnboardingDTO.getProjectName()
        );

        if (userProjectEntity != null) {
            // Combination of user, client, and project already exists
            throw new RuntimeException("User, client, and project combination already exists, please try again.");
        }

        // If the project doesn't exist, we add the project and update the relationship
        ProjectEntity existingProject = projectRepository.findByProjectNameAndClient_ClientId(
                userOnboardingDTO.getProjectName(),
                existingClient.getClientId()
        );

        if (existingProject == null) {
            // Project doesn't exist, create project
            projectRepository.save(new ProjectEntity(userOnboardingDTO.getProjectName(), existingClient));
            responseMessage.append("Project added. ");
            existingProject = projectRepository.findByProjectNameAndClient_ClientId(userOnboardingDTO.getProjectName(), existingClient.getClientId());
        } else {
            responseMessage.append("Project already exists. ");
        }

        // Save the user-project relationship with selected tools
        userProjectRepositorynative.insertUserProject(
                existingUser.getUserId(),
                existingClient.getClientName(),
                userOnboardingDTO.getProjectName(),
                userOnboardingDTO.getToolsSelected()
        );
        responseMessage.append("User assigned to project.");

        return responseMessage.toString().trim(); // Return the final response message
    }
}


