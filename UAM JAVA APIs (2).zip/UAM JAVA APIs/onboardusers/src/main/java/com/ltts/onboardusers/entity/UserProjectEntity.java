package com.ltts.onboardusers.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_project")
public class UserProjectEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userproj_id")
    private Long userProjId;
    
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserEntity user;

    @ManyToOne
    @JoinColumn(name = "client_id", nullable = false)
    private ClientEntity client;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectEntity project;

    @Column(name = "tools_selected", nullable = false)
    private String toolsSelected;

    public Long getUserProjId() {
		return userProjId;
	}

	public void setUserProjId(Long userProjId) {
		this.userProjId = userProjId;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public ClientEntity getClient() {
		return client;
	}

	public void setClient(ClientEntity client) {
		this.client = client;
	}

	public ProjectEntity getProject() {
		return project;
	}

	public void setProject(ProjectEntity project) {
		this.project = project;
	}

	public String getToolsSelected() {
		return toolsSelected;
	}

	public void setToolsSelected(String toolsSelected) {
		this.toolsSelected = toolsSelected;
	}

	

}
