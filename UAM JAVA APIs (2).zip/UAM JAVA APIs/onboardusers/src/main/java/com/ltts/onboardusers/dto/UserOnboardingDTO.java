package com.ltts.onboardusers.dto;


import java.util.List;

public class UserOnboardingDTO {
	
    private String username;
    private String password;
    private String role;
    private String clientName;
    private String projectName;
    private List<String> toolsSelected;
    
    public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public List<String> getToolsSelected() {
		return toolsSelected;
	}
	public void setToolsSelected(List<String> toolsSelected) {
		this.toolsSelected = toolsSelected;
	}
	

    // Getters and setters
}

