package com.ltts.onboardusers.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ltts.onboardusers.entity.UserProjectEntity;

@Repository
public interface UserProjectRepositoryNative extends JpaRepository<UserProjectEntity, Long> {

    @Modifying
    @Query(value = """
        INSERT INTO user_project (user_id, client_id, project_id, Tools_selected)
        VALUES (
            :userId,
            (SELECT client_id FROM Client_Table WHERE client_name = :clientName),
            (SELECT project_id FROM Project_Table WHERE project_name = :projectName AND client_id = (SELECT client_id FROM Client_Table WHERE client_name = :clientName)),
            (SELECT GROUP_CONCAT(DISTINCT tool_name SEPARATOR ';') FROM tools WHERE tool_name IN (:toolsSelected))
        )
    """, nativeQuery = true)
    void insertUserProject(@Param("userId") Long userId,
                           @Param("clientName") String clientName,
                           @Param("projectName") String projectName,
                           @Param("toolsSelected") List<String> toolsSelected);
}
