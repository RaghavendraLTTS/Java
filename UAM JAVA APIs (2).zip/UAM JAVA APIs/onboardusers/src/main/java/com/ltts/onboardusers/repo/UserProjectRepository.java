package com.ltts.onboardusers.repo;

import com.ltts.onboardusers.entity.UserProjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserProjectRepository extends JpaRepository<UserProjectEntity, Long> {
	
	UserProjectEntity findByUser_UserIdAndClient_ClientIdAndProject_ProjectId(Long userId, Long clientId, Integer projectId);
	
	UserProjectEntity findByUser_UserIdAndClient_ClientIdAndProject_ProjectName(Long userId, Long clientId, String projectName);
}
