package com.ltts.onboardusers.dto;

public class ManageUserResponse {
    private Long userProjId;
    private String username;
    private String role;
    private String clientName;
    private String projectName;
    private String toolsSelected;

    public ManageUserResponse(Long userProjId, String username, String role, String clientName, String projectName, String toolsSelected) {
        this.userProjId = userProjId;
        this.username = username;
        this.role = role;
        this.clientName = clientName;
        this.projectName = projectName;
        this.toolsSelected = toolsSelected;
    }
    
    public Long getUserProjId() {
		return userProjId;
	}

	public void setUserProjId(Long userProjId) {
		this.userProjId = userProjId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getToolsSelected() {
		return toolsSelected;
	}

	public void setToolsSelected(String toolsSelected) {
		this.toolsSelected = toolsSelected;
	}



    
}
