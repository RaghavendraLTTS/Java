package com.ltts.onboardusers.dto;


import java.util.List;

public class ClientProjectRequest {
    private String clientName;
    private List<String> projects;

    // Getters and setters
    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public List<String> getProjects() {
        return projects;
    }

    public void setProjects(List<String> projects) {
        this.projects = projects;
    }
}
