package com.ltts.onboardusers.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltts.onboardusers.entity.ProjectEntity;

public interface ProjectRepository extends JpaRepository<ProjectEntity, Long> {
	
    ProjectEntity findByProjectNameAndClient_ClientId(String projectName, Long clientId);
    
    @Query(value = "INSERT INTO project_table (project_name, client_id) VALUES (:projectName, :clientId)", nativeQuery = true)
    void insertProject(@Param("projectName") String projectName, @Param("clientId") Integer clientId);
}
