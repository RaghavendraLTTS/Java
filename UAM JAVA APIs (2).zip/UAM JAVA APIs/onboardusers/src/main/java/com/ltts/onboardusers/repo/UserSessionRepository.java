package com.ltts.onboardusers.repo;

import com.ltts.onboardusers.entity.UserSessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserSessionRepository extends JpaRepository<UserSessionEntity, Long> {
}
