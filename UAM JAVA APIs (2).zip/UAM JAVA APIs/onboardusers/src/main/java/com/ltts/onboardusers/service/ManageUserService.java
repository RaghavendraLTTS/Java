package com.ltts.onboardusers.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.onboardusers.dto.ManageUserResponse;
import com.ltts.onboardusers.repo.ManageUserRepository;

@Service
public class ManageUserService {

    @Autowired
    private ManageUserRepository userProjectRepository;

    public List<ManageUserResponse> getUserProjectData() {
        List<Object[]> results = userProjectRepository.getUserProjectData();
        return results.stream().map(row -> 
            new ManageUserResponse(
            	((Number) row[0]).longValue(),  // userProj_id
                (String) row[1],  // username
                (String) row[2],  // role
                (String) row[3],  // client_name
                (String) row[4],  // project_name
                (String) row[5]   // tools_selected
            )
        ).collect(Collectors.toList());
    }
}
