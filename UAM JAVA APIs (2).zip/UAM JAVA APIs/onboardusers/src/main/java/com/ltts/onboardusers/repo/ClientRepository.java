package com.ltts.onboardusers.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltts.onboardusers.entity.ClientEntity;

public interface ClientRepository extends JpaRepository<ClientEntity, Long> {
    ClientEntity findByClientName(String clientName);
    
    @Query("SELECT c.clientId FROM ClientEntity c WHERE c.clientName = :clientName")
    Long findClientIdByName(@Param("clientName") String clientName);
}
