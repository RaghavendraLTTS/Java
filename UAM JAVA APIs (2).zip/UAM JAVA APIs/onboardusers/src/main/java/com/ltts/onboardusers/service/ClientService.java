package com.ltts.onboardusers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

@Service
public class ClientService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void upsertClientWithProjects(String clientName, List<String> projectNames, List<String> existingProjects) {
        // Check if client exists, if not insert
        int clientId = getClientId(clientName);
        if (clientId == 0) {
            clientId = insertClient(clientName);
        }

        // Insert new projects for the client
        for (String projectName : projectNames) {
            // Check if project already exists for the client
            if (projectExistsForClient(projectName, clientId)) {
                existingProjects.add(projectName);
                System.out.println("Project " + projectName + " already exists for client " + clientName);
            } else {
                insertProject(projectName, clientId);
            }
        }
    }

    private int getClientId(String clientName) {
        String query = "SELECT client_id FROM client_table WHERE client_name = ?";
        return jdbcTemplate.queryForObject(query, new Object[]{clientName}, Integer.class);
    }

    private int insertClient(String clientName) {
        String query = "INSERT INTO client_table (client_name) VALUES (?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(query, new Object[]{clientName}, keyHolder);
        return keyHolder.getKey().intValue();
    }

    private boolean projectExistsForClient(String projectName, int clientId) {
        String query = "SELECT COUNT(*) FROM project_table WHERE project_name = ? AND client_id = ?";
        int count = jdbcTemplate.queryForObject(query, new Object[]{projectName, clientId}, Integer.class);
        return count > 0;
    }

    private void insertProject(String projectName, int clientId) {
        String query = "INSERT INTO project_table (project_name, client_id) VALUES (?, ?)";
        jdbcTemplate.update(query, new Object[]{projectName, clientId});
    }
}