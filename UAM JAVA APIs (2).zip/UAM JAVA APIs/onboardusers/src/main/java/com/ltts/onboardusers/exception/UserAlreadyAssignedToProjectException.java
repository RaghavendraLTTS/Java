package com.ltts.onboardusers.exception;

public class UserAlreadyAssignedToProjectException extends RuntimeException {
    public UserAlreadyAssignedToProjectException(String message) {
        super(message);
    }
}
