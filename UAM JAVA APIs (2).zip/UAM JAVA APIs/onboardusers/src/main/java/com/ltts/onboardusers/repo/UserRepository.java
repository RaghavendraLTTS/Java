package com.ltts.onboardusers.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltts.onboardusers.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long> {
	
	 @Modifying
	    @Query(value = "INSERT INTO UserTable (username, password, Role) VALUES (:username, :password, :role)", nativeQuery = true)
	    void saveUser(@Param("username") String username, @Param("password") String password, @Param("role") String role);

	 UserEntity findByUsername(String username);
	    @Query(value = "SELECT LAST_INSERT_ID()", nativeQuery = true)
	    Long getLastInsertId();
}
