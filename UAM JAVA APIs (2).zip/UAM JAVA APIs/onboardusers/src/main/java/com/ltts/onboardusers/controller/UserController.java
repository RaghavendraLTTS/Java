package com.ltts.onboardusers.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.onboardusers.dto.ManageUserResponse;
import com.ltts.onboardusers.dto.UserOnboardingDTO;
import com.ltts.onboardusers.service.ManageUserService;
import com.ltts.onboardusers.service.UserService;


@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private ManageUserService userProjectService;

    @GetMapping("/manageUsers")
    public List<ManageUserResponse> getUserProjectData() {
        return userProjectService.getUserProjectData();
    }
    
    @PostMapping("/onboardUsers")
    public ResponseEntity<String> onboardUserProject(@RequestBody UserOnboardingDTO userOnboardingDTO) {
        try {
            String result = userService.onboardUserProject(userOnboardingDTO);
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Validation error: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body("Error: " + e.getMessage());  // HTTP 409 Conflict
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Internal server error: " + e.getMessage());
        }
    }
}

