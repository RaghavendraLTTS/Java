//package com.ltts.onboardusers.controller;
//
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ltts.onboardusers.service.ClientService;
//
//@RestController
//@RequestMapping("/api")
//public class ClientController {
//
//    @Autowired
//    private ClientService clientService;
//
//    @PostMapping("/upsert")
//    public ResponseEntity<Map<String, String>> upsertClientWithProjects(@RequestBody Map<String, Object> request) {
//        String clientName = (String) request.get("clientName");
//        @SuppressWarnings("unchecked")
//        List<String> projectNames = (List<String>) request.get("projectNames");
//
//        clientService.upsertClientWithProjects(clientName, projectNames);
//
//        return ResponseEntity.ok(Map.of("message", "Client and projects upserted successfully"));
//    }
//
//
//}
//
