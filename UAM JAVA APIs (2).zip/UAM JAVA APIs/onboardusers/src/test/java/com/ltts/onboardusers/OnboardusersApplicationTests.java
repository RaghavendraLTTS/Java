package com.ltts.onboardusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnboardusersApplicationTests {

	@Test
	void contextLoads() {
	}

}
