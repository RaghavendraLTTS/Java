package com.ltts.updateTools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateToolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
