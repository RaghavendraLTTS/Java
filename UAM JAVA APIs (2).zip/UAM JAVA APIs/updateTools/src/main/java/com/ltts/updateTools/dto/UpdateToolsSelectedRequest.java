package com.ltts.updateTools.dto;


public class UpdateToolsSelectedRequest {

    private Long userProjId;
    private String toolsSelected;

    // Getters and Setters
    public Long getUserProjId() {
        return userProjId;
    }

    public void setUserProjId(Long userProjId) {
        this.userProjId = userProjId;
    }

    public String getToolsSelected() {
        return toolsSelected;
    }

    public void setToolsSelected(String toolsSelected) {
        this.toolsSelected = toolsSelected;
    }
}

