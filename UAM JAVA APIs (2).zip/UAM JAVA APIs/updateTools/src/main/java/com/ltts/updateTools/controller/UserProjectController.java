package com.ltts.updateTools.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.updateTools.dto.UpdateToolsSelectedRequest;
import com.ltts.updateTools.entity.UserProject;
import com.ltts.updateTools.service.UserProjectService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class UserProjectController {

    @Autowired
    private UserProjectService userProjectService;

    @PutMapping("/update-tools-selected")
    public ResponseEntity<String> updateToolsSelected(@RequestBody UpdateToolsSelectedRequest request) {
        Optional<UserProject> updatedUserProject = userProjectService.updateToolsSelected(request.getUserProjId(), request.getToolsSelected());

        if (updatedUserProject.isPresent()) {
            return ResponseEntity.ok("Tools selected updated successfully.");
        } else {
            return ResponseEntity.status(404).body("UserProject not found.");
        }
    }
    
    
    @DeleteMapping("/delete-userproj")
    public ResponseEntity<String> deleteUserProject(@RequestBody Map<String, Integer> request) {
        int userProjId = request.get("id");
        try {
            userProjectService.deleteUserProjectById(userProjId);
            return ResponseEntity.ok("User project deleted successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error deleting user project: " + e.getMessage());
        }
    }
}

