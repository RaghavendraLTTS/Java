package com.ltts.updateTools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdateToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateToolsApplication.class, args);
	}

}
