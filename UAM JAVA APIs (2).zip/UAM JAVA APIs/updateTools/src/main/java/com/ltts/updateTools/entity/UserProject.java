package com.ltts.updateTools.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "user_project")
public class UserProject {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userproj_id")
    private Long userProjId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "client_id")
    private Long clientId;

    @Column(name = "project_id")
    private Long projectId;

    @Column(name = "tools_selected", nullable = false)
    private String toolsSelected;

    // Getters and Setters
    public Long getUserProjId() {
        return userProjId;
    }

    public void setUserProjId(Long userProjId) {
        this.userProjId = userProjId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getToolsSelected() {
        return toolsSelected;
    }

    public void setToolsSelected(String toolsSelected) {
        this.toolsSelected = toolsSelected;
    }
}

