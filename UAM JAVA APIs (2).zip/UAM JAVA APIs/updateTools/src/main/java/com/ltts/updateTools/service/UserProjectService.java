package com.ltts.updateTools.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.updateTools.entity.UserProject;
import com.ltts.updateTools.repo.UserProjectRepository;

import java.util.Optional;

@Service
public class UserProjectService {

    @Autowired
    private UserProjectRepository userProjectRepository;

    public Optional<UserProject> updateToolsSelected(Long userProjId, String toolsSelected) {
        Optional<UserProject> userProjectOptional = userProjectRepository.findById(userProjId);
        if (userProjectOptional.isPresent()) {
            UserProject userProject = userProjectOptional.get();
            userProject.setToolsSelected(toolsSelected);
            userProjectRepository.save(userProject);
            return Optional.of(userProject);
        }
        return Optional.empty();
    }
    
    public void deleteUserProjectById(int userProjId) {
        userProjectRepository.deleteByUserProjId(userProjId);
    }
}

