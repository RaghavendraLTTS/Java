package com.example.workflow.delegate;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.jvnet.hk2.annotations.Service;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

@Service
public class ExceptionHandler implements JavaDelegate {


    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    @Value("${my.echoApiURL}")
    private String URL;

    @Override
    public void execute(DelegateExecution execution) throws URISyntaxException, IOException, InterruptedException {

        String processInstanceId = (String) execution.getProcessInstanceId();
        Object error = (Object) execution.getVariable("errorResponse");
        String pid = (String) execution.getVariable("uniqueProcessId");
        
//        System.out.println("ERRORRRRR : " + error);
//
//        Map<String, Object> request = new HashMap<>();
//        request.put("processInstanceId", pid);
//        request.put("error", error);
//
//        String toolConfigUrl = URL;
//        String jsonInputString = objectMapper.writeValueAsString(request);
//        HttpRequest toolConfigRequest = HttpRequest.newBuilder()
//                .uri(new URI(toolConfigUrl))
//                .header("Content-Type", "application/json")
//                .POST(HttpRequest.BodyPublishers.ofString(jsonInputString))
//                .build();
//        httpClient.send(toolConfigRequest, HttpResponse.BodyHandlers.ofString());

    }
}
