package com.ltts.report.model;

import java.util.List;

public class ProcessDataRequest {
    private List<String> toolname;
    private String startDate;
    private String endDate;

    public List<String> getToolname() {
        return toolname;
    }

    public void setToolname(List<String> toolname) {
        this.toolname = toolname;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
