package com.ltts.report.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltts.report.entity.ProcessData;

public interface ProcessDataRepository extends JpaRepository<ProcessData, Long> {

	@Query(value = "SELECT id, jsondata, process_instanceId, toolname, transactionid, timestamp FROM process_data1 "
			+ "WHERE toolname IN (:toolnames) AND DATE(created_at) BETWEEN :startDate AND :endDate", nativeQuery = true)
	List<Object[]> findProcessData(@Param("toolnames") List<String> toolnames, @Param("startDate") String startDate,
			@Param("endDate") String endDate);
}
