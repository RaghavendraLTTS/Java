package com.ltts.report.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltts.report.model.ProcessDataResponse;
import com.ltts.report.repo.ProcessDataRepository;

@Service
public class ProcessDataService {

    @Autowired
    private ProcessDataRepository processDataRepository;

    @Autowired
    private ObjectMapper objectMapper;

    public List<ProcessDataResponse> getProcessData(List<String> toolnames, String startDate, String endDate) {
        List<Object[]> resultList = processDataRepository.findProcessData(toolnames, startDate, endDate);
        return resultList.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private ProcessDataResponse mapToResponse(Object[] data) {
        Long id = ((Number) data[0]).longValue();
        String jsondata = (String) data[1];
        String processInstanceId = (String) data[2];
        String toolname = (String) data[3];
        Integer transactionId = (Integer) data[4];
        Timestamp timestamp1 = (Timestamp) data[5];
        String timestamp = timestamp1.toString();
//        System.out.println("jsonData : " + jsondata);
        JsonNode jsonNode;
        String report = null;

        try {
            jsonNode = objectMapper.readTree(jsondata);
//            System.out.println("jsonData : " + jsonNode);
            if (jsonNode.has("report")) {
                report = objectMapper.writeValueAsString(jsonNode.get("report"));
            }
        } catch (Exception e) {
            // Handle exception
        }

        return new ProcessDataResponse(id, transactionId, toolname, processInstanceId,timestamp, report);
    }
}
