package com.ltts.report.model;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProcessDataResponse {
    
    private Long id;
    private Integer transactionId;
    private String toolname;
    private String processInstanceId;
    private String timestamp;
	private JsonNode report;

    public ProcessDataResponse(Long id, Integer transactionId, String toolname, String processInstanceId, String timestamp, String report) {
        this.id = id;
        this.transactionId = transactionId;
        this.toolname = toolname;
        this.processInstanceId = processInstanceId;
        this.timestamp = timestamp;
        this.report = convertStringToJson(report);
    }

    // Getter and Setter methods

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }
    
    public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

    public JsonNode getReport() {
        return report;
    }

    public void setReport(JsonNode report) {
        this.report = report;
    }

    // Helper method to convert String to JsonNode
    private JsonNode convertStringToJson(String report) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readTree(report);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
