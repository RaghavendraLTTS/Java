package com.ltts.fileConversion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileConversionApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(FileConversionApplication2.class, args);
	}

}
