package com.ltts.fileConversion.controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aspose.cells.Cells;
import com.aspose.cells.Row;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ltts.fileConversion.util.ConversionUtil;

@RestController
@RequestMapping("/api")
public class FileConversionController {
	

    private static final String JSON_OUTPUT_PATH = "src/main/resources/output.json";
    private static final String DRIVE_C_PATH = "C:/nokia"; // Path to the C: drive

    @PostMapping("/convertFilesToJson")
    public ResponseEntity<?> convertFilesToJson() throws IOException {
    	Long start = System.currentTimeMillis();
    	System.out.println("latestcallrecivedtime = " + LocalDateTime.now());
//    	System.out.println("call recieved");
        List<File> files = getFilesFromDriveC(); // Get list of files from C: drive
		if (files.isEmpty()) {
		    return ResponseEntity.badRequest().body("No files found on drive C:");
		}

		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode resultArray = objectMapper.createArrayNode();

		for (File file : files) {
		    try {
		        ObjectNode fileResult = processFile(file);
		        resultArray.add(fileResult);
		    } catch (Exception e) {
		        e.printStackTrace();
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
		                             .body("Error processing file: " + file.getName() + ", " + e.getMessage());
		    }
		}
		Long endtime = System.currentTimeMillis();
		System.out.println("done Time Taken :" + (endtime - start));
		return ResponseEntity.ok(resultArray);
    }
    
    private List<File> getFilesFromDriveC() {
        List<File> files = new ArrayList<>();
        File[] driveCFiles = new File(DRIVE_C_PATH).listFiles();
        if (driveCFiles != null) {
            for (File file : driveCFiles) {
                if (file.isFile()) {
                    files.add(file);
                }
            }
        }
        return files;
    }

    private ObjectNode processFile(File file) throws Exception {
        String originalFilename = file.getName();
        ObjectNode fileResult = new ObjectMapper().createObjectNode();

        if (originalFilename.toLowerCase().endsWith(".csv")) {
            // Handle CSV file
            String jsonData = ConversionUtil.convertCsvFileToJson(file);
            ArrayNode arrayNode = (ArrayNode) new ObjectMapper().readTree(jsonData);
            fileResult.put("filename", originalFilename);
            fileResult.set("data", arrayNode);
        } else if (originalFilename.toLowerCase().endsWith(".xlsb")) {
            // Handle Excel file
            String jsonData = convertExcelToJson(file);
            ArrayNode arrayNode = (ArrayNode) new ObjectMapper().readTree(jsonData);
            fileResult.put("filename", originalFilename);
            fileResult.set("data", arrayNode);
        } else if (originalFilename.toLowerCase().endsWith(".xml")) {
            // Handle XML file
            String jsonData = convertXmlToJson(file);
            JsonNode jsonNode = new ObjectMapper().readTree(jsonData);
            fileResult.put("filename", originalFilename);
            fileResult.set("data", jsonNode);
        } else {
            // Unsupported file type
            fileResult.put("filename", originalFilename);
            fileResult.put("error", "Unsupported file format");
        }

        return fileResult;
    }

    private String convertExcelToJson(File file) throws Exception {
        Workbook workbook = new Workbook(file.getAbsolutePath());
        Worksheet sheet = workbook.getWorksheets().get(0);
        Cells cells = sheet.getCells();
        Row headerRow = cells.getRows().get(0);
//        int count = 0;
        List<ObjectNode> jsonList = new ArrayList<>();
        for (int rowIndex = 1; rowIndex <= cells.getMaxDataRow(); rowIndex++) {
//        	System.out.println("reading :" + (count++));
            Row dataRow = cells.getRows().get(rowIndex);
            if (dataRow == null) {
                continue;
            }
            ObjectNode jsonObject = new ObjectMapper().createObjectNode();
            for (int colIndex = 0; colIndex <= cells.getMaxDataColumn(); colIndex++) {
//            	System.out.println("reading :" + (count++));
                String header = headerRow.get(colIndex).getStringValue();
                String value = dataRow.get(colIndex).getStringValue();
                jsonObject.put(header, value);
            }
            jsonList.add(jsonObject);
        }

        return jsonList.toString();
    }

    private String convertXmlToJson(File file) throws Exception {
        XmlMapper xmlMapper = new XmlMapper();
        Object xmlObject = xmlMapper.readValue(file, Object.class);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonData = objectMapper.writeValueAsString(xmlObject);
        return ConversionUtil.replacePKeyWithClass(jsonData);
    }
}