package com.ltts.FileConversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileConversionApplicationTests {

	@Test
	void contextLoads() {
	}

}
