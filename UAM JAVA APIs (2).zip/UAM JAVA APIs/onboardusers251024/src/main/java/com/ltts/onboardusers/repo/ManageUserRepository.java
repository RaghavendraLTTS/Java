package com.ltts.onboardusers.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ltts.onboardusers.entity.UserProjectEntity;

@Repository
public interface ManageUserRepository extends CrudRepository<UserProjectEntity, Long> {

    @Query(value = "SELECT d.userProj_id, c.username, c.role, a.client_name, b.project_name, d.tools_selected " +
                   "FROM client_table a, project_table b, usertable c, user_project d " +
                   "WHERE a.client_id = d.client_id AND b.project_id = d.project_id AND c.user_id = d.user_id ORDER BY d.userProj_id ASC", nativeQuery = true)
    List<Object[]> getUserProjectData();
    
    @Query(value = "SELECT d.userProj_id, c.username, c.role, a.client_name, b.project_name, d.tools_selected " +
    		"FROM client_table a, project_table b, usertable c, user_project d " +
    		"WHERE a.client_id = d.client_id " +
    		"AND b.project_id = d.project_id " +
    		"AND c.user_id = d.user_id " +
    		"AND c.username = :username ORDER BY d.userProj_id ASC", nativeQuery = true)
List<Object[]> getUserProjectDataNA(@Param("username") String username);
}
