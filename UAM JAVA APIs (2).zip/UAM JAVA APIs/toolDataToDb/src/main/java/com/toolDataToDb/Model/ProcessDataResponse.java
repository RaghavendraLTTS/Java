package com.toolDataToDb.Model;

import java.time.LocalDateTime;
import com.fasterxml.jackson.databind.JsonNode;

public class ProcessDataResponse {
    private Long id;
    private String username;
    private String client;
    private String project;
    private String toolName;
    private JsonNode jsonData;
    private String processInstanceId;
    private LocalDateTime timestamp;

    public ProcessDataResponse(Long id, String username, String client, String project, String toolName, JsonNode jsonData, String processInstanceId, LocalDateTime timestamp) {
        this.id = id;
        this.username = username;
        this.client = client;
        this.project = project;
        this.toolName = toolName;
        this.jsonData = jsonData;
        this.processInstanceId = processInstanceId;
        this.timestamp = timestamp;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getToolName() {
        return toolName;
    }

    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    public JsonNode getJsonData() {
        return jsonData;
    }

    public void setJsonData(JsonNode jsonData) {
        this.jsonData = jsonData;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
