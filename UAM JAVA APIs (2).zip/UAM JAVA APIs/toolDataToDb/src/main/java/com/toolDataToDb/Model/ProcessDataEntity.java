package com.toolDataToDb.Model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "process_data1")
public class ProcessDataEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String client;
    private String project;
    private String toolname;
    @Column(columnDefinition = "json")
    private String jsondata;
    private String processInstanceid;
    private LocalDateTime timestamp;
    private String processstarttimestamp;

    public String getProcessStartTimeStamp() {
		return processstarttimestamp;
	}
	public void setProcessStartTimeStamp(String processStartTimeStamp) {
		this.processstarttimestamp = processStartTimeStamp;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getToolname() {
		return toolname;
	}
	public void setToolname(String toolname) {
		this.toolname = toolname;
	}
	public String getJsondata() {
		return jsondata;
	}
	public void setJsondata(String jsondata) {
		this.jsondata = jsondata;
	}
	public String getProcessInstanceId() {
		return processInstanceid;
	}
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceid = processInstanceId;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	
}
