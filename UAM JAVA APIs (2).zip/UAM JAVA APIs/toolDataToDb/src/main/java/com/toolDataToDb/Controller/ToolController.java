package com.toolDataToDb.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.toolDataToDb.Model.ProcessDataEntity;
import com.toolDataToDb.Model.ProcessDataResponse;
import com.toolDataToDb.Model.SearchRequest;
import com.toolDataToDb.Repo.ProcessData1Repository;
import com.toolDataToDb.Repo.ProcessDataRepository;
import com.toolDataToDb.Repo.ToolRepository;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ToolController {

    @Autowired
    private ToolRepository toolRepository;
    
    @Autowired
    private ProcessDataRepository pdRepo;
    
    @Autowired
    private ProcessData1Repository pd1Repo;

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${spring.datasource.url}")
    private String jdbcurl;
    
    @Value("${spring.datasource.username}")
    private String username;
    
    @Value("${spring.datasource.password}")
    private String password;
    
//    @PostMapping("/saveToolOutputToDB")
//    public ResponseEntity<Tool> createTool(@RequestBody Map<String, Object> payload) throws JsonProcessingException {
//        Tool tool = new Tool();
//        tool.setProcessInstanceId((String) payload.get("processInstanceId"));
//        tool.setToolName((String) payload.get("toolName"));
//
//        // Convert the nested JSON array to a String
//        String data = objectMapper.writeValueAsString(payload.get("data"));
//        tool.setData(data);
//
//        Tool savedTool = toolRepository.save(tool);
//        return ResponseEntity.ok(savedTool);
//    }
    
    
//    @PostMapping("/process-data")
//    public ResponseEntity<ProcessData> createProcessData(@RequestBody Map<String, Object> payload) throws JsonProcessingException {
//    	ProcessData tool = new ProcessData();
//        tool.setProcessInstanceId((String) payload.get("processInstanceId"));
//        tool.setToolname((String) payload.get("toolname"));
//
//        // Convert the nested JSON array to a String
//        String data = objectMapper.writeValueAsString(payload.get("data"));
//        tool.setData(data);
//
//        ProcessData savedTool = pdRepo.save(tool);
//        return ResponseEntity.ok(savedTool);
//    }
    
    @PostMapping("/process-data1")
    public ResponseEntity<ProcessDataEntity> create(@RequestBody Map<String, Object> payload) throws JsonProcessingException{
    	System.out.println("payloadtooldtatodb  : " +payload);
    	ProcessDataEntity ptool = new ProcessDataEntity();
    	ptool.setUsername((String) payload.get("username"));
    	ptool.setClient((String) payload.get("client"));
    	ptool.setProject((String) payload.get("project"));
    	ptool.setToolname((String) payload.get("toolname"));
    	String input = (String) payload.get("processStartTimeStamp");
    	DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy");
    	LocalDateTime date = LocalDateTime.parse(input, inputFormatter);
    	DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    	String output = date.format(outputFormatter);
    	ptool.setProcessStartTimeStamp((String) output);
    	String data = objectMapper.writeValueAsString(payload.get("jsondata"));
    	ptool.setJsondata(data);
    	ptool.setProcessInstanceId((String) payload.get("processInstanceId"));
        ptool.setTimestamp(LocalDateTime.now());
        ProcessDataEntity savedTool = pd1Repo.save(ptool);
        return ResponseEntity.ok(savedTool);
    }
    
//    
//    @PostMapping("/getToolOutputFromDB")
//    public ResponseEntity<List<ToolResponse>> getToolsByUniqueIDndToolName(@RequestBody SearchRequest request) {
//        String processInstanceId = request.getProcessInstanceId();
//        String toolname = request.getToolName();
//
//        List<ProcessData> tools = toolRepository.findByProcessInstanceidAndToolname(processInstanceId, toolname);
//        System.out.println("Resutl : " + tools);
//
//        List<ToolResponse> formattedTools = tools.stream().map(tool -> {
//            String data = tool.getData();
//            JsonNode jsonData = null;
//            try {
//                jsonData = objectMapper.readTree(data);
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//            }
//
//            // Create a response object with the deserialized data
//            ToolResponse response = new ToolResponse(
//                tool.getId(),
//                tool.getProcessInstanceId(),
//                tool.getToolname(),
//                jsonData,
//                tool.getTimestamp()
//            );
//            return response;
//        }).collect(Collectors.toList());
//
//        return ResponseEntity.ok(formattedTools);
//    }
    
    
    @PostMapping("/getToolOutputFromDB")
    public ResponseEntity<List<ProcessDataResponse>> getToolsByUniqueIDndToolName1(@RequestBody SearchRequest request) {
    	String processInstanceId = request.getProcessInstanceId();
        String toolname = request.getToolName();

        List<ProcessDataEntity> tools = toolRepository.findByProcessInstanceidAndToolname(processInstanceId, toolname);
        System.out.println("Resutl : " + tools);

        List<ProcessDataResponse> formattedTools = tools.stream().map(tool -> {
            String jsonData = tool.getJsondata();
            JsonNode jsonNodeData = null;
            try {
                jsonNodeData = objectMapper.readTree(jsonData);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }

            // Create a response object with the deserialized data
            ProcessDataResponse response = new ProcessDataResponse(
                tool.getId(),
                tool.getUsername(),
                tool.getClient(),
                tool.getProject(),
                tool.getToolname(),
                jsonNodeData,
                tool.getProcessInstanceId(),
                tool.getTimestamp()
            );
            return response;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(formattedTools);
    }
    
    
    @PostMapping("/getAllToolsProcessedData")
    public ResponseEntity<Object> executeQuery(@RequestBody Map<String, String> requestBody) {
        String processInstanceId = requestBody.get("processInstanceId");
        String toolname = requestBody.get("toolname");

        String query = "SELECT JSON_OBJECTAGG(toolname, jsondata) AS result " +
                       "FROM (" +
                       "    SELECT pd.toolname, pd.jsondata " +
                       "    FROM process_data1 pd " +
                       "    JOIN (" +
                       "        SELECT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(predefinedtools, ',', numbers.n), ',', -1)) AS toolname " +
                       "        FROM (" +
                       "            SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL " +
                       "            SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL " +
                       "            SELECT 9 UNION ALL SELECT 10 " +
                       "        ) numbers " +
                       "        JOIN toolconfig tc ON CHAR_LENGTH(tc.predefinedtools) " +
                       "            -CHAR_LENGTH(REPLACE(tc.predefinedtools, ',', ''))>=numbers.n-1 " +
                       "        WHERE tc.toolname = ? " +
                       "    ) t ON pd.toolname = t.toolname " +
                       "    WHERE pd.process_instanceId = ? " +
                       ") AS tools_data";

//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://sql-db.one-touch-mysql-db-server:3306/demo", "root", "ltts");
        try (Connection conn = DriverManager.getConnection(jdbcurl, username, password);		
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, toolname);
            stmt.setString(2, processInstanceId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String jsonResult = rs.getString("result");

                // Parse the JSON string into a JSON object
                ObjectMapper mapper = new ObjectMapper();
                Object jsonObject = mapper.readValue(jsonResult, Object.class);

                return ResponseEntity.ok(jsonObject);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

        } catch (SQLException | IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
}