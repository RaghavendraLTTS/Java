package com.toolDataToDb.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.toolDataToDb.Model.ProcessDataEntity;

public interface ProcessData1Repository extends JpaRepository<ProcessDataEntity, Long> {
}