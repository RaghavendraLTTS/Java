package com.toolDataToDb.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.toolDataToDb.Model.ProcessData;
import com.toolDataToDb.Model.ProcessDataEntity;

@Repository
public interface ToolRepository extends JpaRepository<ProcessDataEntity, Integer> {
	
	List<ProcessDataEntity> findByProcessInstanceidAndToolname(String processInstanceId, String Toolname);

}
