package com.ltts.report.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.report.model.ProcessDataResponse;
import com.ltts.report.repo.ProcessDataRepository;

@Service
public class ProcessDataService {

    @Autowired
    private ProcessDataRepository processDataRepository;

//    @Autowired
//    private ObjectMapper objectMapper;

    public List<ProcessDataResponse> getProcessData(List<String> toolnames, String clientname, String projectname, String startDate, String endDate) {
//    	System.out.println("service request : "+ "toolnames : " + toolnames + " clientname : "+clientname + " projectname : "+projectname + " startDate : "+startDate + " endDate : "+endDate);
        List<Object[]> resultList = processDataRepository.findProcessData(toolnames, clientname, projectname, startDate, endDate);
        return resultList.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private ProcessDataResponse mapToResponse(Object[] data) {
        Long id = ((Number) data[0]).longValue();
        String jsondata = (String) data[1];
        String processInstanceId = (String) data[2];
        String toolname = (String) data[3];
        Integer transactionId = (Integer) data[4];
        Timestamp timestamp1 = (Timestamp) data[5];
        String timestamp = timestamp1.toString();
        String report = jsondata;

        return new ProcessDataResponse(id, transactionId, toolname, processInstanceId,timestamp, report);
    }
}
