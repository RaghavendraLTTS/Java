package com.ltts.report.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.report.model.ProcessDataRequest;
import com.ltts.report.model.ProcessDataResponse;
import com.ltts.report.service.ProcessDataService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/process-data")
public class ProcessDataController {

    @Autowired
    private ProcessDataService processDataService;

//    @PostMapping("/fetch")
//    public List<ProcessDataResponse> fetchProcessData(@RequestBody ProcessDataRequest request) {
//        return processDataService.getProcessData(request.getToolname(), request.getStartDate(), request.getEndDate());
//    }
    @PostMapping("/fetch")
    public ResponseEntity<List<ProcessDataResponse>> getProcessData(
            @RequestBody ProcessDataRequest request) {
        List<ProcessDataResponse> responseList = processDataService.getProcessData(
                request.getToolname(),
                request.getClientname(),
                request.getProjectname(),
                request.getStartDate(), 
                request.getEndDate());
        return ResponseEntity.ok(responseList);
    }
}
