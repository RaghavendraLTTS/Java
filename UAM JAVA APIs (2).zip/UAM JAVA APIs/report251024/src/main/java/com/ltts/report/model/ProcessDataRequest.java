package com.ltts.report.model;

import java.util.List;

public class ProcessDataRequest {
	private List<String> toolname;
	private String clientname;
	private String projectname;
	private String startDate;
	private String endDate;

	public List<String> getToolname() {
		return toolname;
	}

	public void setToolname(List<String> toolname) {
		this.toolname = toolname;
	}

	public String getClientname() {
		return clientname;
	}

	public void setClientname(String clientname) {
		this.clientname = clientname;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
