package com.ltts.loginlogout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginlogoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
