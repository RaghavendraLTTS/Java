package com.ltts.loginlogout.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.loginlogout.entity.User;
import com.ltts.loginlogout.entity.UserSession;

public interface UserSessionRepository extends JpaRepository<UserSession, Long> {
    UserSession findFirstByUserAndLogoutTimeIsNull(User user);
}
