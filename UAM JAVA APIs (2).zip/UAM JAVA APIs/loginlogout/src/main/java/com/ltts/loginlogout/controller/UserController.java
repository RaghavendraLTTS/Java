package com.ltts.loginlogout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ltts.loginlogout.service.UserService;

import java.util.Map;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Signup using JSON body
    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        String role = request.get("role");
        userService.signup(username, password, role);
        return ResponseEntity.ok("Signup successful");
    }

    // Login using JSON body
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        Object response = userService.login(username, password);
        return ResponseEntity.ok(response);
    }

    // Logout using JSON body
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String response = userService.logout(username);
        return ResponseEntity.ok(response);
    }
}
