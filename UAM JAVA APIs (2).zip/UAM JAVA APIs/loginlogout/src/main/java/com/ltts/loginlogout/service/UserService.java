package com.ltts.loginlogout.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltts.loginlogout.entity.User;
import com.ltts.loginlogout.entity.UserSession;
import com.ltts.loginlogout.exception.InvalidEmailException;
import com.ltts.loginlogout.exception.InvalidPasswordException;
import com.ltts.loginlogout.exception.InvalidRoleException;
import com.ltts.loginlogout.repo.UserRepository;
import com.ltts.loginlogout.repo.UserSessionRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserSessionRepository sessionRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private static final String NOKIA_EMAIL_REGEX = "^[A-Za-z0-9._%+-]+@nokia\\.com$";
    private static final Pattern NOKIA_EMAIL_PATTERN = Pattern.compile(NOKIA_EMAIL_REGEX);

    public User signup(String username, String password, String role) {
        validateEmail(username);
        validatePassword(password);
        validateRole(role);

        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);
        return userRepository.save(user);
    }

    public Object login(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            return "Username cannot be empty";
        }
        if (password == null || password.trim().isEmpty()) {
            return "Password cannot be empty";
        }

        User user = userRepository.findByUsername(username);
        if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
            return "Invalid credentials";
        }

        // Logout any active session before starting a new one
        logoutIfAlreadyLoggedIn(user);

        // Create a new session after logging out old one
        UserSession session = new UserSession();
        session.setUser(user);
        session.setUsername(username);
        session.setRole(user.getRole());
        session.setLoginTime(LocalDateTime.now());
        sessionRepository.save(session);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Login successful");
        response.put("username", username);
        response.put("role", user.getRole());

        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(response);
        } catch (JsonProcessingException e) {
            return "Error during login";
        }
    }

    public String logout(String username) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            UserSession activeSession = sessionRepository.findFirstByUserAndLogoutTimeIsNull(user);
            if (activeSession != null) {
                activeSession.setLogoutTime(LocalDateTime.now());
                int duration = (int) Duration.between(activeSession.getLoginTime(), activeSession.getLogoutTime()).toMinutes();
                activeSession.setDuration(duration);
                sessionRepository.save(activeSession);
                return "Logout successful";
            }
        }
        return "User not logged in or no active sessions found";
    }

    /**
     * This method checks if the user has an active session and logs it out.
     */
    private void logoutIfAlreadyLoggedIn(User user) {
        UserSession activeSession = sessionRepository.findFirstByUserAndLogoutTimeIsNull(user);
        if (activeSession != null) {
            // User already logged in, logging out the current session
            activeSession.setLogoutTime(LocalDateTime.now());
            int duration = (int) Duration.between(activeSession.getLoginTime(), activeSession.getLogoutTime()).toMinutes();
            activeSession.setDuration(duration);
            sessionRepository.save(activeSession);
        }
    }

    // Validation methods for email, password, and role
    private void validateEmail(String email) {
        if (email == null || email.isEmpty() || !NOKIA_EMAIL_PATTERN.matcher(email).matches()) {
            throw new InvalidEmailException("Email must be valid and end with @example.com");
        }
    }

    private void validatePassword(String password) {
        if (password == null || password.isEmpty()) {
            throw new InvalidPasswordException("Password cannot be empty");
        }
        // Add more validations as needed
    }

    private void validateRole(String role) {
        if (role == null || role.isEmpty()) {
            throw new InvalidRoleException("Role cannot be empty");
        }
    }
}
