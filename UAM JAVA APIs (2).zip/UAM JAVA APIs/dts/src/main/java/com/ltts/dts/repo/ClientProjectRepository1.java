package com.ltts.dts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltts.dts.entity.ClientProject;

public interface ClientProjectRepository1 extends JpaRepository<ClientProject, Long> {

	@Query(value = "SELECT a.client_name, b.project_name "
			+ "FROM client_table a, project_table b, user_project c, usertable d "
			+ "WHERE a.client_id = b.client_id AND b.client_id = c.client_id AND "
			+ "b.project_id = c.project_id AND c.user_id = d.user_id AND "
			+ "d.username = :username", nativeQuery = true)
	List<Object[]> findByUsername(@Param("username") String username);
}
