package com.ltts.dts.controller;


import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.dts.entity.dts;
import com.ltts.dts.model.DtsResponse;
import com.ltts.dts.model.dtsRequest;
import com.ltts.dts.repo.DtsRepository;
import com.ltts.dts.repo.service.ViewTimeSumService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/users")
public class UserController {
	
	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
    private DtsRepository dtsRepo;
	
	private final ViewTimeSumService viewTimeSumService;

    public UserController(ViewTimeSumService viewTimeSumService) {
        this.viewTimeSumService = viewTimeSumService;
    }
	
	@GetMapping("/dtsentry")
    public String enterDts() {
        try {
            dts dashboardTimeStamp = new dts();
            LocalDateTime date = LocalDateTime.now();
        	// Add 5 hours and 30 minutes
        	date = date.plusHours(5).plusMinutes(30);
            dashboardTimeStamp.setEntryTime(date);
            dtsRepo.save(dashboardTimeStamp);
            return "Welcome to the dashboard!";
        } catch (Exception e) {
            log.error("Error entering dashboard: {}", e.getMessage());
            return "Error entering dashboard";
        }
    }

    @PostMapping("/dtsexit")
    public ResponseEntity<String> exitDts(@RequestBody dtsRequest req) {
        try {
            List<dts> dashboardTimeStamps = dtsRepo.findTopByExitTimeIsNullOrderByEntryTimeDesc();
            if (!dashboardTimeStamps.isEmpty()) {
                dts dashboardTimeStamp = dashboardTimeStamps.get(0); // Take the first result
                LocalDateTime date = LocalDateTime.now();
            	// Add 5 hours and 30 minutes
            	date = date.plusHours(5).plusMinutes(30);
                dashboardTimeStamp.setExitTime(date);
                dashboardTimeStamp.setViewTime(req.getViewTime());
                dashboardTimeStamp.setUsername(req.getUserName());
                dashboardTimeStamp.setClient(req.getClient());
                dashboardTimeStamp.setProject(req.getProject());
                dashboardTimeStamp.setToolname(req.getToolname());
                dtsRepo.save(dashboardTimeStamp);
                return ResponseEntity.ok("Exited dashboard successfully");
            } else {
                return ResponseEntity.badRequest().body("No active session found");
            }
        } catch (Exception e) {
            log.error("Error exiting dashboard: {}", e.getMessage());
            return ResponseEntity.badRequest().body("Error exiting dashboard");
        }
    }
    
    
    @GetMapping("/getDts")
    public ResponseEntity<List<DtsResponse>> getAllDts() {
        List<dts> dtsList = dtsRepo.findAll();
        List<DtsResponse> dtsResponseList = dtsList.stream()
            .map(dts -> {
                DtsResponse dtsResponse = new DtsResponse();
//                dtsResponse.setId(dts.getId());
                dtsResponse.setUsername(dts.getUsername());
                dtsResponse.setClient(dts.getClient());
                dtsResponse.setProject(dts.getProject());
                dtsResponse.setToolname(dts.getToolname());
                dtsResponse.setDashboardOpenTimestamp(dts.getEntryTime().toString());
                if(dts.getExitTime() != null) {
                dtsResponse.setDashboardCloseTimestamp(dts.getExitTime().toString());
                }
                dtsResponse.setActualTimeSpent(dts.getViewTime());
                return dtsResponse;
            })
            .collect(Collectors.toList());

        return ResponseEntity.ok(dtsResponseList);
    }
    
    @GetMapping("/view-time-sum")
    public @ResponseBody  Map<Object, String> getViewTimeSum() {
        Map<Object, String> resultMap = viewTimeSumService.getViewTimeSum();
        return (resultMap);
    }
}
