package com.ltts.dts.model;

public class DtsResponse  {

//	private Long id;
	
	private String username;

	private String client;

	private String project;

	private String toolname;

	private String dashboardOpenTimestamp;

	private String dashboardCloseTimestamp;

	private String actualTimeSpent;
	
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getToolname() {
		return toolname;
	}

	public void setToolname(String toolname) {
		this.toolname = toolname;
	}

	public String getDashboardOpenTimestamp() {
		return dashboardOpenTimestamp;
	}

	public void setDashboardOpenTimestamp(String dashboardOpenTimestamp) {
		this.dashboardOpenTimestamp = dashboardOpenTimestamp;
	}

	public String getDashboardCloseTimestamp() {
		return dashboardCloseTimestamp;
	}

	public void setDashboardCloseTimestamp(String dashboardCloseTimestamp) {
		this.dashboardCloseTimestamp = dashboardCloseTimestamp;
	}

	public String getActualTimeSpent() {
		return actualTimeSpent;
	}

	public void setActualTimeSpent(String actualTimeSpent) {
		this.actualTimeSpent = actualTimeSpent;
	}

	

	

}
