package com.ltts.dts.repo.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.dts.model.ClientProjectResponse;
import com.ltts.dts.repo.ClientProjectRepository;
import com.ltts.dts.repo.ClientProjectRepository1;

@Service
public class ClientProjectService {

    @Autowired
    private ClientProjectRepository clientProjectRepository;
    
    @Autowired
    private ClientProjectRepository1 clientProjectRepository1;

    public List<Map<String, Object>> getClientProjectData() {
        return clientProjectRepository.fetchClientProjectData();
    }
    
    public List<ClientProjectResponse> getClientsAndProjectsByUsername(String username) {
        List<Object[]> results = clientProjectRepository1.findByUsername(username);
        List<ClientProjectResponse> response = new ArrayList<>();
        Map<String, ClientProjectResponse> clientProjects = new HashMap<>();
        
        for (Object[] result : results) {
            String clientName = (String) result[0];
            String projectName = (String) result[1];
            
            if (!clientProjects.containsKey(clientName)) {
                ClientProjectResponse clientProjectResponse = new ClientProjectResponse();
                clientProjectResponse.setClient(clientName);
                clientProjectResponse.setProjects(new ArrayList<>());
                clientProjects.put(clientName, clientProjectResponse);
            }
            
            clientProjects.get(clientName).getProjects().add(projectName);
        }
        
        response.addAll(clientProjects.values());
        return response;
    }
}

