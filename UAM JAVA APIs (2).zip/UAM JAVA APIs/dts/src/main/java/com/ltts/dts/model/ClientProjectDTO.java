package com.ltts.dts.model;


public class ClientProjectDTO {
    
    private Long clientId;
    private String clientName;
    private Long projectId;
    private String projectName;
    private Long clientClientId;

    // Default constructor
    public ClientProjectDTO() {
    }

    // Parameterized constructor
    public ClientProjectDTO(Long clientId, String clientName, Long projectId, String projectName, Long clientClientId) {
        this.clientId = clientId;
        this.clientName = clientName;
        this.projectId = projectId;
        this.projectName = projectName;
        this.clientClientId = clientClientId;
    }

    // Getters and Setters
    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Long getClientClientId() {
        return clientClientId;
    }

    public void setClientClientId(Long clientClientId) {
        this.clientClientId = clientClientId;
    }

    // toString method for debugging and logging purposes
    @Override
    public String toString() {
        return "ClientProjectDTO{" +
                "clientId=" + clientId +
                ", clientName='" + clientName + '\'' +
                ", projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", clientClientId=" + clientClientId +
                '}';
    }
}
