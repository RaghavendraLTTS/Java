package com.ltts.dts.repo.service;

import java.time.Duration;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ltts.dts.repo.DtsRepository;

@Service
public class ViewTimeSumService {

    private final DtsRepository viewTimeRepository;

    public ViewTimeSumService(DtsRepository viewTimeRepository) {
        this.viewTimeRepository = viewTimeRepository;
    }

        public Map<Object, String> getViewTimeSum() {
            List<String> viewTimes = viewTimeRepository.getViewTimesFromDatabase();
            System.out.println("Query Result : " + viewTimes);

            Duration totalDuration = Duration.ZERO;
            for (String viewTime : viewTimes) {
                if(viewTime != null && !viewTime.trim().isEmpty()) {
                LocalTime time = LocalTime.parse(viewTime);
                totalDuration = totalDuration.plus(Duration.ofHours(time.getHour()))
                        .plus(Duration.ofMinutes(time.getMinute()))
                        .plus(Duration.ofSeconds(time.getSecond()));
            }
            }
        long totalHours = totalDuration.toHours();
        long remainingMinutes = totalDuration.toMinutes() % 60;
        Map<Object, String> resultMap = new HashMap<>();
        resultMap.put("TotalNonDigitalHr", totalHours + " Hrs " + remainingMinutes + " M");
        return resultMap;
    }
}