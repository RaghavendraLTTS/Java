package com.ltts.dts.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

import com.ltts.dts.entity.dts;
import com.ltts.dts.model.ClientProjectCombination;
import com.ltts.dts.model.ClientProjectResponse;
import com.ltts.dts.model.DtsResponse;
import com.ltts.dts.model.UsernameRequest;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class DtsNAController {
	
	private static final Logger log = LoggerFactory.getLogger(DtsNAController.class);
	private RestTemplate restTemplate = new RestTemplate();
	
	@Value("${my.cpapi}")
    private String cpapi;
    
    @Value("${my.ltdNAapi}")
    private String ltdNAapi;
    
    @Value("${spring.datasource.url}")
    private String jdbcurl;
    
    @Value("${spring.datasource.username}")
    private String username;
    
    @Value("${spring.datasource.password}")
    private String password;
	
	@PostMapping("/getDtsNA")
    public ResponseEntity<List<DtsResponse>> getProcessDataWithUsername(@RequestBody UsernameRequest request) {
        try {
            // Call the first API to get the client project combinations
            ResponseEntity<List<ClientProjectResponse>> response = getClientsAndProjects(request);
            System.out.println(" api response : " + response.getBody());

            if (response.getStatusCode() == HttpStatus.OK) {
                List<ClientProjectResponse> clientProjectResponses = response.getBody();
                List<ClientProjectCombination> combinations = new ArrayList<>();

                for (ClientProjectResponse clientProjectResponse : clientProjectResponses) {
                    ClientProjectCombination combination = new ClientProjectCombination();
                    combination.setClient(clientProjectResponse.getClient());
                    combination.setProjects(clientProjectResponse.getProjects());
                    combinations.add(combination);
                }

                // Call the second API with the client project combinations
                return getDtsData(combinations);
            } else {
                return ResponseEntity.status(response.getStatusCode()).build();
            }
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling API: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to API: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error processing request: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("/combinations")
    public ResponseEntity<List<DtsResponse>> getProcessData(@RequestBody List<ClientProjectCombination> combinations) {
      StringBuilder query = new StringBuilder("SELECT username, client, project, toolname, entry_time, exit_time, view_time FROM dts WHERE ");
      
      for (int i = 0; i < combinations.size(); i++) {
        ClientProjectCombination combination = combinations.get(i);
        query.append("(")
              .append("client = '").append(combination.getClient()).append("' AND project IN (");
        
        for (String project : combination.getProjects()) {
          query.append("'").append(project).append("',");
        }
        
        query.deleteCharAt(query.length() - 1); // remove trailing comma
        query.append("))");
        
        if (i < combinations.size() - 1) {
          query.append(" OR ");
        }
      }
      
      System.out.println("query print : "+ query.toString());
      try (Connection conn = DriverManager.getConnection(jdbcurl, username, password);		
               PreparedStatement stmt = conn.prepareStatement(query.toString())) {
        
        ResultSet resultSet = stmt.executeQuery();
        
        List<dts> gpd = new ArrayList<>();
        while (resultSet.next()) {
        	dts processTable = new dts();
//          processTable.setId(resultSet.getInt("id"));
          processTable.setUsername(resultSet.getString("username"));
          processTable.setClient(resultSet.getString("client"));
          processTable.setProject(resultSet.getString("project"));
          processTable.setToolname(resultSet.getString("toolname"));
          processTable.setEntryTime(resultSet.getObject("entry_time", LocalDateTime.class));
          processTable.setExitTime(resultSet.getObject("exit_time", LocalDateTime.class));
          processTable.setViewTime(resultSet.getString("view_time"));
          gpd.add(processTable);
        }
        
        if(gpd.size() != 0){
          List<DtsResponse> responses = gpd.stream()
                  .map(processData -> {
                	  DtsResponse response = new DtsResponse();
                   response.setUsername(processData.getUsername());	  
                   response.setClient(processData.getClient());
                   response.setProject(processData.getProject());
                   response.setToolname(processData.getToolname());
                   response.setDashboardOpenTimestamp(processData.getEntryTime().toString());
                   if(processData.getExitTime() != null) {
                	   response.setDashboardCloseTimestamp(processData.getExitTime().toString());
                       }
                   response.setActualTimeSpent(processData.getViewTime());
                   
                   return response;
                  })
                  .collect(Collectors.toList());
          
          return ResponseEntity.ok(responses);
        } else {
          return ResponseEntity.noContent().build();
        }
      } catch (SQLException e) {
        // handle SQLException
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
      }
    }
	
	private ResponseEntity<List<ClientProjectResponse>> getClientsAndProjects(UsernameRequest request) {
        try {
            String baseUrl = cpapi; 
            restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(baseUrl));
            return restTemplate.exchange("/clients-and-projects", HttpMethod.POST, new HttpEntity<>(request), new ParameterizedTypeReference<List<ClientProjectResponse>>() {});
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling first API: {}", e.getMessage());
            throw e;
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to first API: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error calling first API: {}", e.getMessage());
            throw e;
        }
    }

    
    private ResponseEntity<List<DtsResponse>> getDtsData(List<ClientProjectCombination> combinations) {
        try {
            String baseUrl = ltdNAapi; 
            restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(baseUrl));
            return restTemplate.exchange("/combinations", HttpMethod.POST, new HttpEntity<>(combinations), new ParameterizedTypeReference<List<DtsResponse>>() {});
        } catch (HttpServerErrorException e) {
            // Handle 500 error
            log.error("Error calling second API: {}", e.getMessage());
            throw e;
        } catch (ResourceAccessException e) {
            // Handle connection refused or timeout errors
            log.error("Error connecting to second API: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Error calling second API: {}", e.getMessage());
            throw e;
        }
    }
}
