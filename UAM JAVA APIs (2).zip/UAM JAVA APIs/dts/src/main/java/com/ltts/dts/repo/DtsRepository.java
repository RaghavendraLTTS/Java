package com.ltts.dts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ltts.dts.entity.dts;



public interface DtsRepository extends JpaRepository<dts, Long> {
    @Query("SELECT d FROM dts d WHERE d.exitTime IS NULL ORDER BY d.entryTime DESC")
    List<dts> findTopByExitTimeIsNullOrderByEntryTimeDesc();
    
   @Query(value = "select view_time from dts", nativeQuery = true)
   List<String> getViewTimesFromDatabase(); 
}
