package com.ltts.dts.model;

import java.util.List;

public class ClientProjectCombination {
    private String client;
    private List<String> projects;

    public ClientProjectCombination() {} // Add a no-argument constructor

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public List<String> getProjects() {
        return projects;
    }

    public void setProjects(List<String> projects) {
        this.projects = projects;
    }
}
