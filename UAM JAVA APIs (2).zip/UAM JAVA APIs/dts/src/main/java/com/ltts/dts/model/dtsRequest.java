package com.ltts.dts.model;

//public class dtsRequest {
//
//	private String viewTime;
//	private String userName;
//	
//	public String getViewTime() {
//		return viewTime;
//	}
//	public void setViewTime(String viewTime) {
//		this.viewTime = viewTime;
//	}
//	public String getUserName() {
//		return userName;
//	}
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//	
//}


public class dtsRequest {

    private String viewTime;
    private String userName;
    private String client;
    private String project;
    private String toolname;
    
    public String getViewTime() {
        return viewTime;
    }
    public void setViewTime(String viewTime) {
        this.viewTime = viewTime;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getClient() {
        return client;
    }
    public void setClient(String client) {
        this.client = client;
    }
    public String getProject() {
        return project;
    }
    public void setProject(String project) {
        this.project = project;
    }
    public String getToolname() {
        return toolname;
    }
    public void setToolname(String toolname) {
        this.toolname = toolname;
    }
}