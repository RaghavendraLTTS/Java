package com.ltts.toolStats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToolStatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToolStatsApplication.class, args);
	}

}
