package com.ltts.toolStats.enitity;

import java.sql.Timestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ProcessData1 {
    @Id
    private Long transactionId;
    private Timestamp timestamp;
    private Timestamp processstarttimestamp;
    
    public Timestamp getProcessstarttimestamp() {
		return processstarttimestamp;
	}
	public void setProcessstarttimestamp(Timestamp processstarttimestamp) {
		this.processstarttimestamp = processstarttimestamp;
	}
	public Long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	
}