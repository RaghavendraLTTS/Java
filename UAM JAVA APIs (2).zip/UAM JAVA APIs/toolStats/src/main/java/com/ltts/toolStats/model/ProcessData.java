package com.ltts.toolStats.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ProcessData {
	@Id
	private Long userid;
    private Long transactionid;
    private String username;
    private String client;
    private String project;
    private String toolname;
    private String processinstanceid;
    private String exectimestamp;
    private String processendtimestamp;
    private String processingtime;

    // Constructors
    public ProcessData() {
    }

    public ProcessData(Long transactionId, Long userId, String username, String client, String project, String toolname, 
                       String processInstanceId, String execTimeStamp, String processEndTimestamp, 
                       String processingTime) {
        this.transactionid = transactionId;
        this.userid = userId;
        this.username = username;
        this.client = client;
        this.project = project;
        this.toolname = toolname;
        this.processinstanceid = processInstanceId;
        this.exectimestamp = execTimeStamp;
        this.processendtimestamp = processEndTimestamp;
        this.processingtime = processingTime;
    }

    // Getters and Setters

    public Long getTransactionId() {
        return transactionid;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionid = transactionId;
    }

    public Long getUserId() {
        return userid;
    }

    public void setUserId(Long userId) {
        this.userid = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getProcessInstanceId() {
        return processinstanceid;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processinstanceid = processInstanceId;
    }

    public String getExecTimeStamp() {
        return exectimestamp;
    }

    public void setExecTimeStamp(String execTimeStamp) {
        this.exectimestamp = execTimeStamp;
    }

    public String getProcessEndTimestamp() {
        return processendtimestamp;
    }

    public void setProcessEndTimestamp(String processEndTimestamp) {
        this.processendtimestamp = processEndTimestamp;
    }

    public String getProcessingTime() {
        return processingtime;
    }

    public void setProcessingTime(String processingTime) {
        this.processingtime = processingTime;
    }
}
