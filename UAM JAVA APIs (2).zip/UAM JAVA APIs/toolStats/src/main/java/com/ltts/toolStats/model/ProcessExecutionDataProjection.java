package com.ltts.toolStats.model;


public interface ProcessExecutionDataProjection {
    Long getTransactionId();
    Long getUserId();
    String getUsername();
    String getClient();
    String getProject();
    String getToolname();
    String getProcessInstanceId();
    String getExecTimeStamp();
    String getProcessEndTimestamp();
    String getProcessingTime();
}

