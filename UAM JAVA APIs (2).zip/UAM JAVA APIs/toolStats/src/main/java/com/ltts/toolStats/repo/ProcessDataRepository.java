package com.ltts.toolStats.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ltts.toolStats.model.ProcessData;

public interface ProcessDataRepository extends CrudRepository<ProcessData, Long> {

    @org.springframework.data.jpa.repository.Query(value = "SELECT \n"
            + "  b.id as userId,\n"
            + "  b.transactionId, \n"
            + "  b.username, \n"
            + "  b.client, \n"
            + "  b.project, \n"
            + "  b.toolname, \n"
            + "  b.process_instanceId AS processInstanceId, \n"
            + "  b.processstarttimestamp AS execTimeStamp, \n"
            + "  b.timestamp AS processEndTimestamp, \n"
            + "  TIMESTAMPDIFF(SECOND, b.processstarttimestamp, b.timestamp) AS processingTime \n"
            + "FROM \n"
            + "  process_data1 b \n"
            + "WHERE b.username = :username",
            nativeQuery = true)
    List<ProcessData> fetchProcessExecutionDataByUsername(@Param("username") String username);
    
    
    @org.springframework.data.jpa.repository.Query(value = "SELECT \n"
    		+ "  b.id as userId,\n"
    		+ "  b.transactionId, \n"
    		+ "  b.username, \n"
    		+ "  b.client, \n"
    		+ "  b.project, \n"
    		+ "  b.toolname, \n"
    		+ "  b.process_instanceId AS processInstanceId, \n"
    		+ "  b.processstarttimestamp AS execTimeStamp, \n"
    		+ "  b.timestamp AS processEndTimestamp, \n"
    		+ "  TIMESTAMPDIFF(SECOND, b.processstarttimestamp, b.timestamp) AS processingTime \n"
    		+ "FROM \n"
    		+ "  process_data1 b",
           nativeQuery = true)
    List<ProcessData> fetchProcessExecutionData();
}





