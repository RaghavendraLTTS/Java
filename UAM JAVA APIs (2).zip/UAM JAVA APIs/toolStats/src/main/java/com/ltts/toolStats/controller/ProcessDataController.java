package com.ltts.toolStats.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltts.toolStats.model.ProcessData;
import com.ltts.toolStats.model.ProcessExecutionDataResponse;
import com.ltts.toolStats.model.TotalDigitalHrResponse;
import com.ltts.toolStats.repo.ProcessDataRepository;
import com.ltts.toolStats.service.ExecutionDataService;
//import com.ltts.toolStats.service.ProcessDataService;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api/process")
public class ProcessDataController {

//	@Autowired
//	private ProcessDataService processDataService;

	@Autowired
	private ExecutionDataService service;

	@Autowired
	private ProcessDataRepository processDataRepository;

	@GetMapping("/total-digital-hr")
	public TotalDigitalHrResponse findTotalDigitalHr() {
		return service.findTotalDigitalHr();
	}
	
	@GetMapping("/toolStatsForSA")
	public ResponseEntity<List<ProcessExecutionDataResponse>> getProcessExecutionData() {

	    List<ProcessData> pd = processDataRepository.fetchProcessExecutionData();
	    if (pd.size() != 0) {
	        List<ProcessExecutionDataResponse> responses = pd.stream().map(proData -> {
	            ProcessExecutionDataResponse response = new ProcessExecutionDataResponse();
	            response.setUserId(proData.getUserId());
	            response.setUsername(proData.getUsername());
	            response.setClient(proData.getClient());
	            response.setProject(proData.getProject());
	            response.setToolname(proData.getToolname());
	            response.setProcessInstanceId(proData.getProcessInstanceId());
	            response.setExecTimeStamp(proData.getExecTimeStamp());
	            response.setProcessEndTimestamp(proData.getProcessEndTimestamp());
	            response.setProcessingTime(proData.getProcessingTime());
	            response.setTransactionId(proData.getTransactionId());
	            return response; // return statement was missing
	        }).collect(Collectors.toList());
	        return ResponseEntity.ok(responses);
	    } else {
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<>()); 
	    }
	}

	@PostMapping("/toolStatsForNA")
	public ResponseEntity<List<ProcessExecutionDataResponse>> getProcessExecutionData(@RequestBody Map<String, String> requestBody) {
	    
	    String username = requestBody.get("username");  // Extract username from JSON request

	    if (username == null || username.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ArrayList<>());  // Handle empty or missing username
	    }

	    List<ProcessData> pd = processDataRepository.fetchProcessExecutionDataByUsername(username);
	    if (!pd.isEmpty()) {
	        List<ProcessExecutionDataResponse> responses = pd.stream().map(proData -> {
	            ProcessExecutionDataResponse response = new ProcessExecutionDataResponse();
	            response.setUserId(proData.getUserId());
	            response.setUsername(proData.getUsername());
	            response.setClient(proData.getClient());
	            response.setProject(proData.getProject());
	            response.setToolname(proData.getToolname());
	            response.setProcessInstanceId(proData.getProcessInstanceId());
	            response.setExecTimeStamp(proData.getExecTimeStamp());
	            response.setProcessEndTimestamp(proData.getProcessEndTimestamp());
	            response.setProcessingTime(proData.getProcessingTime());
	            response.setTransactionId(proData.getTransactionId());
	            return response;
	        }).collect(Collectors.toList());
	        return ResponseEntity.ok(responses);
	    } else {
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(new ArrayList<>()); 
	    }
	}

}
