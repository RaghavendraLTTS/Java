package com.ltts.toolStats.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.toolStats.model.TotalDigitalHrResponse;
import com.ltts.toolStats.repo.ExecutionDataRepository;

@Service
public class ExecutionDataService {
    @Autowired
    private ExecutionDataRepository repository;
    
    public TotalDigitalHrResponse findTotalDigitalHr() {
        Long hours = repository.findTotalHours();
        Long minutes = repository.findTotalMinutes();
        TotalDigitalHrResponse response = new TotalDigitalHrResponse();
        response.setTotalDigitalHr(String.format("%dhrs %dMin", hours, minutes));
        return response;
    }
}


    

