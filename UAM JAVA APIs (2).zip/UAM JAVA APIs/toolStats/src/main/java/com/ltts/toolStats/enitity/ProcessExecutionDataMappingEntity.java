package com.ltts.toolStats.enitity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityResult;
import jakarta.persistence.FieldResult;
import jakarta.persistence.Id;
import jakarta.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(
    name = "ProcessExecutionDataMapping",
    entities = {
        @EntityResult(
            entityClass = ProcessExecutionDataMappingEntity.class,
            fields = {
                @FieldResult(name = "userId", column = "userId"),
                @FieldResult(name = "transactionId", column = "transactionId"),
                @FieldResult(name = "username", column = "username"),
                @FieldResult(name = "client", column = "client"),
                @FieldResult(name = "project", column = "project"),
                @FieldResult(name = "toolname", column = "toolname"),
                @FieldResult(name = "processInstanceId", column = "process_instanceId"),
                @FieldResult(name = "execTimeStamp", column = "execTimeStamp"),
                @FieldResult(name = "processEndTimestamp", column = "processEndTimestamp"),
                @FieldResult(name = "processingTime", column = "processingTime")
            }
        )
    }
)
public class ProcessExecutionDataMappingEntity {

    @Id
    @Column(name = "userId")
    private Long userId;

    @Column(name = "transactionId")
    private Long transactionId;

    @Column(name = "username")
    private String username;

    @Column(name = "client")
    private String client;

    @Column(name = "project")
    private String project;

    @Column(name = "toolname")
    private String toolname;

    @Column(name = "process_instanceId")
    private String processInstanceId;

    @Column(name = "execTimeStamp")
    private LocalDateTime execTimeStamp;

    @Column(name = "processEndTimestamp")
    private LocalDateTime processEndTimestamp;

    @Column(name = "processingTime")
    private String processingTime;

    public Long getId() {
        return userId;
    }

    public void setId(Long id) {
        this.userId = id;
    }

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public LocalDateTime getExecTimeStamp() {
        return execTimeStamp;
    }

    public void setExecTimeStamp(LocalDateTime execTimeStamp) {
        this.execTimeStamp = execTimeStamp;
    }

    public LocalDateTime getProcessEndTimestamp() {
        return processEndTimestamp;
    }

    public void setProcessEndTimestamp(LocalDateTime processEndTimestamp) {
        this.processEndTimestamp = processEndTimestamp;
    }

    public String getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(String processingTime) {
        this.processingTime = processingTime;
    }
}
