package com.ltts.toolStats.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ltts.toolStats.enitity.ProcessData1;

public interface ExecutionDataRepository extends JpaRepository<ProcessData1, Long> {
	@Query(value = "SELECT FLOOR(SUM(TIMESTAMPDIFF(SECOND, b.processstarttimestamp, b.timestamp)) / 3600) FROM process_data1 b", nativeQuery = true)
	Long findTotalHours();

	@Query(value = "SELECT MOD(FLOOR(SUM(TIMESTAMPDIFF(SECOND, b.processstarttimestamp, b.timestamp)) / 60), 60) FROM process_data1 b", nativeQuery = true)
	Long findTotalMinutes();
}
