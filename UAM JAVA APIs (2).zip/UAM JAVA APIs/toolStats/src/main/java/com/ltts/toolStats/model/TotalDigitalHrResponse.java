package com.ltts.toolStats.model;

public class TotalDigitalHrResponse {
    private String totalDigitalHr;

	public String getTotalDigitalHr() {
		return totalDigitalHr;
	}

	public void setTotalDigitalHr(String totalDigitalHr) {
		this.totalDigitalHr = totalDigitalHr;
	}
}
