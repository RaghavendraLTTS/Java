package com.ltts.toolStats.model;


public class ProcessExecutionDataResponse {
	
	private Long userId;
	private String username;
	private String client;
	private String project;
	private String toolname;
	private String processInstanceId;
	private String execTimeStamp;
	private String processEndTimestamp;
	private String processingTime;
	private Long transactionId;

//	public ProcessExecutionDataResponse(Long transactionId, Long userId, String username, String client, String project,
//			String toolname, String processInstanceId, String execTimeStamp, String processEndTimestamp,
//			String processingTime) {
//		this.transactionId = transactionId;
//		this.userId = userId;
//		this.username = username;
//		this.client = client;
//		this.project = project;
//		this.toolname = toolname;
//		this.processInstanceId = processInstanceId;
//		this.execTimeStamp = execTimeStamp;
//		this.processEndTimestamp = processEndTimestamp;
//		this.processingTime = processingTime;
//	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getToolname() {
		return toolname;
	}

	public void setToolname(String toolname) {
		this.toolname = toolname;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public String getExecTimeStamp() {
		return execTimeStamp;
	}

	public void setExecTimeStamp(String execTimeStamp) {
		this.execTimeStamp = execTimeStamp;
	}

	public String getProcessEndTimestamp() {
		return processEndTimestamp;
	}

	public void setProcessEndTimestamp(String processEndTimestamp) {
		this.processEndTimestamp = processEndTimestamp;
	}

	public String getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(String processingTime) {
		this.processingTime = processingTime;
	}
	
	public String getFormattedProcessingTime() {
        try {
            int seconds = Integer.parseInt(processingTime);
            int hours = seconds / 3600;
            int minutes = (seconds % 3600) / 60;
            int secs = seconds % 60;

            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        } catch (NumberFormatException e) {
            return "Invalid time";
        }
    }

}
