package com.ltts.toolStats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToolStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
