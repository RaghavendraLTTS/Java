package com.ltts.executiondata.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltts.executiondata.controller.model.Executiondata;

public interface ExecutionRepo extends JpaRepository<Executiondata, Long> {

	List<Executiondata> findByUsername(String username);
}
