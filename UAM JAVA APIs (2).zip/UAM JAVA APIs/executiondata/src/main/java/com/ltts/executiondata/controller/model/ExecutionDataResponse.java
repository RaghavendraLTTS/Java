package com.ltts.executiondata.controller.model;

import java.time.LocalDateTime;

public class ExecutionDataResponse {
	
    private String username;
    private String clientName;
    private String projectName;
    private String[] tools;
    private String timestamp;
    
    public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String[] getTools() {
		return tools;
	}
	public void setTools(String[] tools) {
		this.tools = tools;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
}
