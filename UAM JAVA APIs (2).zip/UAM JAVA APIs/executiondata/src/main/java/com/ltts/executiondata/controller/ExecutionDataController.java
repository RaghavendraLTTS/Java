package com.ltts.executiondata.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltts.executiondata.controller.model.ExecutionDataRequest;
import com.ltts.executiondata.controller.model.ExecutionDataResponse;
import com.ltts.executiondata.controller.model.Executiondata;
import com.ltts.executiondata.repo.ExecutionRepo;

@RestController
@CrossOrigin(origins = "${ui.crossOrigin}")
@RequestMapping("/api")
public class ExecutionDataController {


    @Autowired
    private ExecutionRepo repo;
    
    @PostMapping("/executiondata")
    public ResponseEntity<String> createExecutionData(@RequestBody ExecutionDataRequest request) {
        Executiondata executiondata = new Executiondata();
        executiondata.setUsername(request.getUsername());
        executiondata.setClient(request.getClientName());
        executiondata.setProject(request.getProjectName());
        try {
			executiondata.setToolname(new ObjectMapper().writeValueAsString(request.getTools()));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
       
    	LocalDateTime date = LocalDateTime.now();
    	// Add 5 hours and 30 minutes
    	date = date.plusHours(5).plusMinutes(30);
        executiondata.setTimestamp(date);
        repo.save(executiondata);
        return ResponseEntity.ok("Data inserted successfully");
    }
    
    
    @GetMapping("/getexecutiondataSA")
    public ResponseEntity<List<ExecutionDataResponse>> getExecutionData() {
        List<Executiondata> executionDataList = repo.findAll();
        if(executionDataList.size() != 0){
            List<ExecutionDataResponse> responses = executionDataList.stream()
                    .map(executionData -> {
                        ExecutionDataResponse response = new ExecutionDataResponse();
                        response.setUsername(executionData.getUsername());
                        response.setClientName(executionData.getClient());
                        response.setProjectName(executionData.getProject());
                        try {
							response.setTools(new ObjectMapper().readValue(executionData.getToolname(),String[].class));
						} catch (JsonProcessingException e) {
							e.printStackTrace();
						} // assuming toolname is a single string
                        response.setTimestamp(executionData.getTimestamp().toString());
                        return response;
                    })
                    .collect(Collectors.toList());
            return ResponseEntity.ok(responses);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }
    
    @PostMapping("/getexecutiondataNA")
    public ResponseEntity<List<ExecutionDataResponse>> getExecutionDataByUsername(@RequestBody Map<String, String> requestBody) {
        String username = requestBody.get("username");
        
        // Fetch data based on the username from the repository
        List<Executiondata> executionDataList = repo.findByUsername(username);

        if (!executionDataList.isEmpty()) {
            List<ExecutionDataResponse> responses = executionDataList.stream()
                    .map(executionData -> {
                        ExecutionDataResponse response = new ExecutionDataResponse();
                        response.setUsername(executionData.getUsername());
                        response.setClientName(executionData.getClient());
                        response.setProjectName(executionData.getProject());
                        try {
                            response.setTools(new ObjectMapper().readValue(executionData.getToolname(), String[].class));
                        } catch (JsonProcessingException e) {
                            e.printStackTrace();
                        }
                        response.setTimestamp(executionData.getTimestamp().toString());
                        return response;
                    })
                    .collect(Collectors.toList());
            return ResponseEntity.ok(responses);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
        }
    }

}